from scipy.io import loadmat

data_list = [
        "D:\Data\TrainingSet\musk1+.mat",
        "D:\Data\TrainingSet\musk2+.mat",
        "D:\Data\TrainingSet\Data\Data\Mutagenesis\mutagenesis1.mat",
        "D:\Data\TrainingSet\Data\Data\Mutagenesis\mutagenesis2.mat",
        "D:\Data\TrainingSet\Data\Data\Benchmark\elephant+.mat",
        "D:\Data\TrainingSet\Data\Data\Benchmark\Fox+.mat",
        "D:\Data\TrainingSet\Data\Data\Benchmark\\tiger+.mat",
        "D:\Data\TrainingSet\Data\Data\Breast(688)\messidor+.mat",
        "D:\Data\TrainingSet\Data\Data\Text(sparse)\\unnormalized\\alt_atheism.mat",
        "D:\Data\TrainingSet\Data\Data\Text(sparse)\\normalized\\alt_atheism+.mat",
        "D:\Data\TrainingSet\Data\Data\Text(sparse)\\unnormalized\comp_graphics.mat",
        "D:\Data\TrainingSet\Data\Data\Text(sparse)\\normalized\\comp_graphics+.mat",
        "D:\Data\TrainingSet\Data\Data\Text(sparse)\\unnormalized\comp_os_ms-windows_misc.mat",
        "D:\Data\TrainingSet\Data\Data\Text(sparse)\\unnormalized\comp_sys_mac_hardware.mat",
        "D:\Data\TrainingSet\Data\Data\Text(sparse)\\unnormalized\misc_forsale.mat",
        "D:\Data\TrainingSet\Data\Data\Text(sparse)\\unnormalized\\rec_sport_baseball.mat",
        "D:\Data\TrainingSet\Data\Data\Text(sparse)\\unnormalized\\rec_sport_hockey.mat",
        "D:\Data\TrainingSet\Data\Data\Text(sparse)\\unnormalized\sci_electronics.mat",
        "D:\Data\TrainingSet\Data\Data\Text(sparse)\\unnormalized\sci_med.mat",
        "D:\Data\TrainingSet\Data\Data\Text(sparse)\\unnormalized\sci_space.mat",
        "D:\Data\TrainingSet\Data\Data\Web(sparse)\web1+.mat",
        "D:\Data\TrainingSet\Data\Data\Web(sparse)\web2+.mat",
        "D:\Data\TrainingSet\Data\Data\Web(sparse)\web3+.mat",
        "D:\Data\TrainingSet\Data\Data\Web(sparse)\web4+.mat",
        "D:\Data\TrainingSet\Data\Data\Web(sparse)\web5+.mat",
        "D:\Data\TrainingSet\Data\Data\Web(sparse)\web6+.mat",
        "D:\Data\TrainingSet\Data\Data\Web(sparse)\web7+.mat",
        "D:\Data\TrainingSet\Data\Data\Web(sparse)\web8+.mat",
        "D:\Data\TrainingSet\Data\Data\Web(sparse)\web9+.mat",
    ]

for i in range(len(data_list)):
    musk = loadmat(data_list[i])