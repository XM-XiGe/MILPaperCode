"""
@author: Inki
@contact: inki.yinji@qq.com
@version: Created in 2020 0907 1601, last modified in 2021 0415.
"""

import numpy as np
import warnings
import time
from StableMIL2 import StableMIL
from ClassifyTool import Classify
from MnistLoadTool import MnistLoader
warnings.filterwarnings('ignore')


"""
        "D:\Data\TrainingSet\musk1+.mat",
        "D:\Data\TrainingSet\musk2+.mat",
        "D:\Data\TrainingSet\Data\Data\Mutagenesis\mutagenesis1.mat",
        "D:\Data\TrainingSet\Data\Data\Mutagenesis\mutagenesis2.mat",
        "D:\Data\TrainingSet\Data\Data\Benchmark\elephant+.mat",
        "D:\Data\TrainingSet\Data\Data\Benchmark\Fox+.mat",
        "D:\Data\TrainingSet\Data\Data\Benchmark\\tiger+.mat",
        "D:\Data\TrainingSet\Data\Data\Breast(688)\messidor+.mat",
        "D:\Data\TrainingSet\Data\Data\Text(sparse)\\unnormalized\\alt_atheism.mat",
        "D:\Data\TrainingSet\Data\Data\Text(sparse)\\normalized\\alt_atheism+.mat",
        "D:\Data\TrainingSet\Data\Data\Text(sparse)\\unnormalized\comp_graphics.mat",
        "D:\Data\TrainingSet\Data\Data\Text(sparse)\\normalized\\comp_graphics+.mat",
        "D:\Data\TrainingSet\Data\Data\Text(sparse)\\unnormalized\comp_os_ms-windows_misc.mat",
        "D:\Data\TrainingSet\Data\Data\Text(sparse)\\unnormalized\comp_sys_mac_hardware.mat",
        "D:\Data\TrainingSet\Data\Data\Text(sparse)\\unnormalized\misc_forsale.mat",
        "D:\Data\TrainingSet\Data\Data\Text(sparse)\\unnormalized\\rec_sport_baseball.mat",
        "D:\Data\TrainingSet\Data\Data\Text(sparse)\\unnormalized\\rec_sport_hockey.mat",
        "D:\Data\TrainingSet\Data\Data\Text(sparse)\\unnormalized\sci_electronics.mat",
        "D:\Data\TrainingSet\Data\Data\Text(sparse)\\unnormalized\sci_med.mat",
        "D:\Data\TrainingSet\Data\Data\Text(sparse)\\unnormalized\sci_space.mat",
        "D:\Data\TrainingSet\Data\Data\Web(sparse)\web1+.mat",
        "D:\Data\TrainingSet\Data\Data\Web(sparse)\web2+.mat",
        "D:\Data\TrainingSet\Data\Data\Web(sparse)\web3+.mat",
        "D:\Data\TrainingSet\Data\Data\Web(sparse)\web4+.mat",
        "D:\Data\TrainingSet\Data\Data\Web(sparse)\web5+.mat",
        "D:\Data\TrainingSet\Data\Data\Web(sparse)\web6+.mat",
        "D:\Data\TrainingSet\Data\Data\Web(sparse)\web7+.mat",
        "D:\Data\TrainingSet\Data\Data\Web(sparse)\web8+.mat",
        "D:\Data\TrainingSet\Data\Data\Web(sparse)\web9+.mat",
"""

data_list = [
    "D:\Data\TrainingSet\musk2+.mat",
    ]

def _10cv(this_path,tau2,yinguo_ins_num):
    """
    """
    print("-----------------------------------------")
    tau1 = 1
    tau2 = tau2
    k_m = 1
    is_turn = False
    data_path = this_path
    yinguo_ins_num = yinguo_ins_num

    print("tau1:",tau1)
    print("tau2:", tau2)
    print("k_m",k_m)
    print("is_turn",is_turn)
    print("yinguo_ins_num",yinguo_ins_num)
    """======================================================="""
    loops = 50
    te_f1_k, te_acc_k, te_roc_k = np.zeros(loops), np.zeros(loops), np.zeros(loops)
    te_f1_s, te_acc_s, te_roc_s = np.zeros(loops), np.zeros(loops), np.zeros(loops)
    te_f1_j, te_acc_j, te_roc_j = np.zeros(loops), np.zeros(loops), np.zeros(loops)
    print("NewStableMIL with %s" % (data_path.split("/")[-1].split(".")[0]))

    mil = StableMIL(data_path, yinguo_ins_num=yinguo_ins_num,bag_space=None,tau1=tau1,tau2=tau2,is_turn=is_turn,k_m=k_m)
    """
        tau1:从正包中选代表示例的个数
        tau2:负包（负裁判）的个数
        k_m:从miVLAD中选代表示例的个数
        is_turn:是否反选
        k:k倍交叉验证
    """


    for i in range(loops):
        classifier = Classify(["knn", "svm", "j48"], ["f1_score", "acc", "roc"])
        s_t = time.time()
        data_iter = mil.get_mapping()
        te_per = classifier.test(data_iter)
        # print("%.2lf" % ((time.time() - s_t) * 1000))
        # tr_f1_k[i], tr_acc_k[i], tr_roc_k[i] = tr_per["knn"][0], tr_per["knn"][1], tr_per["knn"][2]
        # tr_f1_s[i], tr_acc_s[i], tr_roc_s[i] = tr_per["svm"][0], tr_per["svm"][1], tr_per["svm"][2]
        # tr_f1_j[i], tr_acc_j[i], tr_roc_j[i] = tr_per["j48"][0], tr_per["j48"][1], tr_per["j48"][2]
        te_f1_k[i], te_acc_k[i], te_roc_k[i] = te_per["knn"][0], te_per["knn"][1], te_per["knn"][2]
        te_f1_s[i], te_acc_s[i], te_roc_s[i] = te_per["svm"][0], te_per["svm"][1], te_per["svm"][2]
        te_f1_j[i], te_acc_j[i], te_roc_j[i] = te_per["j48"][0], te_per["j48"][1], te_per["j48"][2]
        '''
        print("%.4lf, %.4lf, %.4lf; %.4lf, %.4lf, %.4lf; %.4lf, %.4lf, %.4lf; \n"
              % (te_f1_k[i], te_acc_k[i], te_roc_k[i],
                 te_f1_s[i], te_acc_s[i], te_roc_s[i],
                 te_f1_j[i], te_acc_j[i], te_roc_j[i]
                 ), end=" ")

        '''

    print("knn-f1 std   knn-acc std   knn-roc std   svm-f1 std    svm-acc std   svm-roc std   "
          "j48-f1 std    j48-acc std   j48-roc std")

    '''
    print("%.4lf %.4lf "
          "%.4lf %.4lf "
          "%.4lf %.4lf " % (np.sum(te_acc_k) / loops, np.std(te_acc_k),
                            np.sum(te_acc_s) / loops, np.std(te_acc_s),
                            np.sum(te_acc_j) / loops, np.std(te_acc_j),
                            ), end="")
    '''

    if(np.sum(te_acc_k)>np.sum(te_acc_s) and np.sum(te_acc_k)>np.sum(te_acc_j)):
        print("%.4lf %.4lf " % (np.sum(te_acc_k) / loops, np.std(te_acc_k),
                                ), end="")
    if (np.sum(te_acc_s) > np.sum(te_acc_k) and np.sum(te_acc_s) > np.sum(te_acc_j)):
        print("%.4lf %.4lf " % (np.sum(te_acc_s) / loops, np.std(te_acc_s),
                                ), end="")
    if (np.sum(te_acc_j) > np.sum(te_acc_k) and np.sum(te_acc_j) > np.sum(te_acc_s)):
        print("%.4lf %.4lf " % (np.sum(te_acc_j) / loops, np.std(te_acc_j),
                                ), end="")


"""
print("%.4lf %.4lf %.4lf %.4lf %.4lf %.4lf "
          "%.4lf %.4lf %.4lf %.4lf %.4lf %.4lf "
          "%.4lf %.4lf %.4lf %.4lf %.4lf %.4lf " % (np.sum(te_f1_k) / loops, np.std(te_f1_k),
                                                    np.sum(te_acc_k) / loops, np.std(te_acc_k),
                                                    np.sum(te_roc_k) / loops, np.std(te_roc_k),
                                                    np.sum(te_f1_s) / loops, np.std(te_f1_s),
                                                    np.sum(te_acc_s) / loops, np.std(te_acc_s),
                                                    np.sum(te_roc_s) / loops, np.std(te_roc_s),
                                                    np.sum(te_f1_j) / loops, np.std(te_f1_j),
                                                    np.sum(te_acc_j) / loops, np.std(te_acc_j),
                                                    np.sum(te_roc_j) / loops, np.std(te_roc_j)), end="")
"""

if __name__ == '__main__':
    s_t = time.time()
    yinguo_num =[3,17]
    for i in range(len(data_list)):
         for j in range(len(yinguo_num)):
            _10cv(data_list[i],tau2=0.05,yinguo_ins_num=yinguo_num[j])
            print("\ntime:","%.4f" % (time.time() - s_t))
            #print("%.4f" % (time.time() - s_t))
            print("======================一个数据集跑完啦=============================")
