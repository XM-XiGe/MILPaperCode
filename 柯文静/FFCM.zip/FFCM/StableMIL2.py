"""
作者：因吉 (Inki)
邮箱：inki.yinji@gmail.com
创建时间： 2021 0630
进一次修改：2021 0630.
注意：参考文献：Robust Multi-Instance Learning with Stable Instances (2020)
     参考博客：https://blog.csdn.net/weixin_44575152/article/details/118208353
"""
import numpy as np
from sklearn.svm import SVC
from sklearn.cluster import MiniBatchKMeans
from sklearn.metrics import euclidean_distances
from Prototype import MIL
from FunctionTool import get_k_cross_validation_index, max_similarity, dis_euclidean


class StableMIL(MIL):

    def __init__(self, path,yinguo_ins_num,tau1=1, tau2=0.1, k_m=1, is_turn=False, k=10, bag_space=None):
        """
        构造器
        :param      tau: 阈值
        tau1:从正包中选代表示例的个数
        tau2:负包（负裁判）的个数
        k_m:从miVLAD中选代表示例的个数(局部映射向量的个数)
        is_turn:是否反选
        k:k倍交叉验证

        """
        super(StableMIL, self).__init__(path, bag_space=bag_space)
        self.tau1 = tau1
        self.tau2 = tau2
        self.k_m = k_m
        self.is_turn = is_turn
        self.k = k
        self.vector = []
        self.tr_idx = []
        self.te_idx = []
        self.__initialize_stable_mil()
        self.yinguo_ins_num = yinguo_ins_num

    def __initialize_stable_mil(self):
        """
        初始化
        """
        self.vector = np.zeros((self.num_bag, self.num_att))
        for i in range(self.num_bag):
            temp_bag = self.bag_space[i][0][:, :-1]
            self.vector[i] = np.average(temp_bag, 0)

    def __mapping(self, ins_pool):
        """
        包映射
        """
        ret_map = np.zeros((self.num_bag, len(ins_pool)))
        for i in range(self.num_bag):
            bag = self.bag_space[i][0][:, :-1]
            for j, ins in enumerate(ins_pool):
                ret_map[i][j] = max_similarity(bag, ins)
        return ret_map

    def __mivlad_bag_mapping(self, bag, centers, labels):
        """
        Mapping each given bag by using centers.
        @param:
            idx:
                The index of bag to be mapped.
            centers:
                The clustering centers of kMeans clustering algorithm.
            labels:
                The label for bag's instances which indicate the center to which the instance belongs.
        """
        ret_vec = np.zeros((1, self.num_att))
        idx_ins = 0
        dis_ = np.zeros((len(bag),len(centers)))
        #计算距离矩阵
        for i in range(len(bag)):
            for j in range(len(centers)):
                dis= dis_euclidean(centers[j],bag[i])
                dis_[i,j] = dis

        for ins in bag:
            zuijin_ins_index = np.argsort(dis_[idx_ins])[0]
            v_jubu = ins-centers[zuijin_ins_index]
            ret_vec += v_jubu
            idx_ins += 1
        ret_vec = np.resize(ret_vec, self.k_m * self.num_att)
        ret_vec = np.sign(ret_vec) * np.sqrt(np.abs(ret_vec))
        return ret_vec / dis_euclidean(ret_vec, np.zeros_like(ret_vec))

    def get_mapping(self):
        """
        Split training set and test set.
        """

        # 获取训练集测试集索引
        self.tr_idx, self.te_idx = get_k_cross_validation_index(self.num_bag)
        # 找到负包标签
        if self.is_turn:
            po_lab, ne_lab = max(self.bag_lab), min(self.bag_lab)
        else:
            po_lab, ne_lab = min(self.bag_lab), max(self.bag_lab)
        # 分类器和聚类器
        classifier = SVC(max_iter=10000, probability=True)
        cluster = MiniBatchKMeans(n_clusters=self.k_m)
        # 主循环
        for loop in range(self.k):
            """步骤1. 使用miVLAD配对SVM作为基分类器"""
            tr_idx, te_idx = self.tr_idx[loop], self.te_idx[loop]
            tr_ins, _, _ = self.get_sub_ins_space(tr_idx)
            cluster.fit(tr_ins)
            centers = cluster.cluster_centers_
            # 包映射
            mapping_mat = np.zeros((len(tr_idx), self.k_m * self.num_att))
            for i, idx in enumerate(tr_idx):
                mapping_mat[i] = self.__mivlad_bag_mapping(self.get_bag(idx), centers, cluster.predict(self.get_bag(idx)))
            classifier.fit(mapping_mat, self.bag_lab[tr_idx])

            """步骤2：筛减包"""
            possibility = classifier.predict_proba(mapping_mat)
            po_idx = np.where(self.bag_lab[tr_idx] == po_lab)[0]
            ne_idx = np.where(self.bag_lab[tr_idx] == ne_lab)[0]
            # po_possibility = possibility[po_idx][:, po_lab]
            ne_possibility = possibility[ne_idx][:, ne_lab]
            # max_po_idx = np.array(tr_idx)[np.argsort(po_possibility)[::-1][:self.tau1]]
            max_ne_idx = np.array(tr_idx)[np.argsort(ne_possibility)[::-1][:int(self.tau2*len(po_idx))]]

            """步骤3：寻找因果实例"""
            # max_ins, _, _ = self.get_sub_ins_space(max_po_idx)
            max_ins = []
            yinguo_ins = []
            score = np.zeros(len(po_idx))
            for i, idx in enumerate(po_idx):
                bag = self.get_bag(idx)
                ins = bag[euclidean_distances(bag).sum(0).argmin()]
                max_ins.append(ins)
                for j in max_ne_idx:
                    new_bag = np.vstack([self.get_bag(j), ins])
                    vec = self.__mivlad_bag_mapping(new_bag, centers, cluster.predict(new_bag)).reshape(1, -1)
                    hat_possibility = classifier.predict_proba(vec)[0][po_lab]
                    score[i] += hat_possibility
                score[i] /= len(max_ne_idx)

            yinguo_ins = np.array(max_ins)[np.argsort(score)[::-1][:self.yinguo_ins_num]]


            """步骤4：基于因果实例预测包"""
            mapping_mat = np.zeros((self.num_bag, self.num_att))
            for i in range(self.num_bag):
                mapping_mat[i] = self.__mivlad_bag_mapping(self.get_bag(i), yinguo_ins, cluster.predict(self.get_bag(i)))

            yield (mapping_mat[tr_idx], self.bag_lab[tr_idx],
                   mapping_mat[te_idx], self.bag_lab[te_idx], None)
