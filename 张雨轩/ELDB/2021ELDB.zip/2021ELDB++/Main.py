import argparse
import numpy as np
from ELDB import ELDB


def get_parser():
    """默认参数设置"""
    mode_bag_init = 'g'
    parser = argparse.ArgumentParser(description="多示例学习ELDB算法的参数设置")
    parser.add_argument("--alpha", default=0.75, type=float, help="学习率")
    parser.add_argument("--psi_max", default=1000, type=int, help="最大选取包数")
    parser.add_argument("--mode_bag_init", default=mode_bag_init, help="初始dBagSet选取模式")
    parser.add_argument("--mode-action", default=mode_action, help="行为模式")
    parser.add_argument("--k", default=3)
    parser.add_argument("--type_performance", default=["f1_score"], type=list, help="性能度量指标")

    return parser.parse_args()


def main():
    """
    测试
    """
    args = get_parser()
    eldb = ELDB(data_path=data_path, psi=psi, alpha=args.alpha, psi_max=args.psi_max,
                type_b2b=b2b, mode_bag_init=args.mode_bag_init, type_performance=args.type_performance,
                mode_action=args.mode_action, k=args.k, bag_space=bag_space, print_loop=True)
    results = {}
    classifier_type, metric_type = eldb.get_state()
    # 获取完整的CV实验结果
    for i in range(args.k):
        result_temp = eldb.get_mapping()
        for classifier in classifier_type:
            for metric in metric_type:
                val_temp = float("{:.4f}".format(result_temp[classifier + ' ' + metric]))
                if i == 0:
                    results[classifier + ' ' + metric] = [val_temp]
                else:
                    results[classifier + ' ' + metric].append(val_temp)
    # 计算平均值以及标准差
    # print("当前分类结果：")
    for metric in metric_type:
        best_ave[metric] = 0
        # print("\t{:s}度量：".format(metric))
        key = ct + ' ' + metric
        print(results[key])
        ave_temp = np.average(results[key]) * 100
        std_temp = np.std(results[key], ddof=1) * 100
        if psi == 1:
            print("& $%.2lf_{\pm %.2lf}$\\\\" % (ave_temp, std_temp))
        else:
            print("& $%.2lf_{\pm %.2lf}$                          " % (ave_temp, std_temp), end="")


if __name__ == '__main__':
    """进行实验时需要修改的参数"""
    # 数据集的路径
    # data_path = "D:/OneDrive/Files/Code/Data/MIL/Drug/musk1+.mat"
    data_path = "test.mat"
    bag_space = "test"
    # po_label = 9
    # data_path = "fashion_mnist" + str(po_label) + ".none"
    # 行为模式，对应于aELDB和rELDB
    mode_action = 'a'  # or 'r'
    ct = "svm"

    # 用于记录最佳分类器的分类结果
    best_classifier, best_ave, best_std = {}, {}, {}
    # 获取数据集名称
    data_name = data_path.split('/')[-1].split('.')[0]
    # from BagLoader import BagLoader
    # bag_space = BagLoader(seed=1, po_label=po_label, data_type="fashion_mnist", data_path="D:/Data/").bag_space
    print("实验数据集{:s}".format(data_name))
    for b2b in ["sim"]:
        print("& %s                                     " % b2b.upper(), end="")
        # for psi in np.arange(0.1, 1.1, 0.1):
        psi = 0.9
        main()
