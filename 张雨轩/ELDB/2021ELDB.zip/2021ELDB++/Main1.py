"""
@author: Inki
@contact: inki.yinji@qq.com
@version: Created in 2020 0907 1601, last modified in 2021 0415.
"""

import numpy as np
import warnings
import argparse
from ELDB import ELDB
warnings.filterwarnings('ignore')

data_list = ["D:/Data/OneDrive/Code/MIL1/Data/Drug/musk1+.mat",
             # "D:/Data/OneDrive/Code/MIL1/Data/Drug/musk2+.mat",
             # "D:/Data/OneDrive/Code/MIL1/Data/Image/elephant+.mat",
             # "D:/Data/OneDrive/Code/MIL1/Data/Image/fox+.mat",
             # "D:/Data/OneDrive/Code/MIL1/Data/Image/tiger+.mat",
             # "D:/Data/OneDrive/Code/MIL1/Data/Web/web1+.mat",
             # "D:/Data/OneDrive/Code/MIL1/Data/Web/web2+.mat",
             # "D:/Data/OneDrive/Code/MIL1/Data/Web/web3+.mat",
             # "D:/Data/OneDrive/Code/MIL1/Data/Web/web4+.mat",
             # "D:/Data/OneDrive/Code/MIL1/Data/Web/web5+.mat",
             # "D:/Data/OneDrive/Code/MIL1/Data/Web/web6+.mat",
             # "D:/Data/OneDrive/Code/MIL1/Data/Web/web7+.mat",
             # "D:/Data/OneDrive/Code/MIL1/Data/Web/web8+.mat",
             # "D:/Data/OneDrive/Code/MIL1/Data/Web/web9+.mat",
             # "D:/Data/OneDrive/Code/MIL1/Data/Text/alt_atheism.mat",
             # "D:/Data/OneDrive/Code/MIL1/Data/Text/comp_graphics.mat",
             # "D:/Data/OneDrive/Code/MIL1/Data/Text/comp_os_ms-windows_misc.mat",
             # "D:/Data/OneDrive/Code/MIL1/Data/Text/comp_sys_ibm_pc_hardware.mat",
             # "D:/Data/OneDrive/Code/MIL1/Data/Text/comp_sys_mac_hardware.mat",
             # "D:/Data/OneDrive/Code/MIL1/Data/Text/comp_windows_x.mat",
             # "D:/Data/OneDrive/Code/MIL1/Data/Text/misc_forsale.mat",
             # "D:/Data/OneDrive/Code/MIL1/Data/Text/rec_autos.mat",
             # "D:/Data/OneDrive/Code/MIL1/Data/Text/rec_motorcycles.mat",
             # "D:/Data/OneDrive/Code/MIL1/Data/Text/rec_sport_baseball.mat",
             # "D:/Data/OneDrive/Code/MIL1/Data/Text/rec_sport_hockey.mat",
             # "D:/Data/OneDrive/Code/MIL1/Data/Text/sci_crypt.mat",
             # "D:/Data/OneDrive/Code/MIL1/Data/Text/sci_electronics.mat",
             # "D:/Data/OneDrive/Code/MIL1/Data/Text/sci_med.mat",
             # "D:/Data/OneDrive/Code/MIL1/Data/Text/sci_religion_christian.mat",
             # "D:/Data/OneDrive/Code/MIL1/Data/Text/sci_space.mat",
             # "D:/Data/OneDrive/Code/MIL1/Data/Text/talk_politics_guns.mat",
             # "D:/Data/OneDrive/Code/MIL1/Data/Text/talk_politics_mideast.mat",
             # "D:/Data/OneDrive/Code/MIL1/Data/Text/talk_politics_misc.mat",
             # "D:/Data/OneDrive/Code/MIL1/Data/Text/talk_religion_misc.mat",
             # "D:/Data/OneDrive/Code/MIL1/Data/Mutagenesis/mutagenesis1.mat",
             # "D:/Data/OneDrive/Code/MIL1/Data/Mutagenesis/mutagenesis2.mat",
             ]

def get_parser():
    """默认参数设置"""
    mode_bag_init = 'g'
    parser = argparse.ArgumentParser(description="多示例学习ELDB算法的参数设置")
    parser.add_argument("--alpha", default=0.75, type=float, help="学习率")
    parser.add_argument("--psi_max", default=200, type=int, help="最大选取包数")
    parser.add_argument("--mode_bag_init", default=mode_bag_init, help="初始dBagSet选取模式")
    parser.add_argument("--mode-action", default=mode_action, help="行为模式")
    parser.add_argument("--k", default=10)
    parser.add_argument("--type_performance", default=["f1_score"], type=list, help="性能度量指标")

    return parser.parse_args()

def main():
    """
    测试
    """
    args = get_parser()
    eldb = ELDB(data_path="", alpha=args.alpha, psi_max=args.psi_max,
                mode_bag_init=args.mode_bag_init, type_performance=args.type_performance,
                mode_action=args.mode_action, k=args.k, bag_space=None)
    results = {}
    classifier_type, metric_type = eldb.get_state()
    # 获取完整的CV实验结果
    for i in range(10):
        result_temp = eldb.get_mapping()
        for classifier in classifier_type:
            for metric in metric_type:
                val_temp = float("{:.4f}".format(result_temp[classifier + ' ' + metric]))
                if i == 0:
                    results[classifier + ' ' + metric] = [val_temp]
                else:
                    results[classifier + ' ' + metric].append(val_temp)
    # 计算平均值以及标准差
    # print("当前分类结果：")
    for metric in metric_type:
        # print("\t{:s}度量：".format(metric))
        key = ct + ' ' + metric
        print("%.4lf, %.4lf, %.4lf" % (np.average(results["knn " + metric]), np.average(results["svm " + metric]),
              np.average(results["j48 " + metric])), end=", ")


if __name__ == '__main__':
    """进行实验时需要修改的参数"""
    # 数据集的路径
    mode_action = 'a'  # or 'r'
    ct = "svm"

    for data_path in data_list:
    # for po_label in range(10):
        from BagLoader import BagLoader
        # bag_space = BagLoader(po_label=po_label, data_type="fashion_mnist", data_path="D:/Data/").bag_space
        # for i in range(3):
        main()
        print()
