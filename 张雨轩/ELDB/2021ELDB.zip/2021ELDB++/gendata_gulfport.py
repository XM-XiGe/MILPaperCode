﻿import os
import pdb
import sys

sys.path.append(r".\public")
# from public.load_data import loadmat
import numpy as np
import scipy.io as spio

from sklearn import preprocessing
"""
在计算距离时使用了numba加速
"""


def loadmat(filename):
    '''
    this function should be called instead of direct spio.loadmat
    as it cures the problem of not properly recovering python dictionaries
    from mat files. It calls the function check keys to cure all entries
    which are still mat-objects
    '''
    data = spio.loadmat(filename, struct_as_record=False, squeeze_me=True)
    return _check_keys(data)


def _check_keys(dict):
    '''
    checks if entries in dictionary are mat-objects. If yes
    todict is called to change them to nested dictionaries
    '''
    for key in dict:
        if isinstance(dict[key], spio.matlab.mio5_params.mat_struct):
            dict[key] = _todict(dict[key])
    return dict
def _todict(matobj):
    '''
    A recursive function which constructs from matobjects nested dictionaries
    '''
    dict = {}
    for strg in matobj._fieldnames:
        elem = matobj.__dict__[strg]
        if isinstance(elem, spio.matlab.mio5_params.mat_struct):
            dict[strg] = _todict(elem)
        else:
            dict[strg] = elem
    return dict


def train_dataset(path: str, padding_size: int = 25):
    pos_data1 = loadmat(path + 'pos_bags1.mat')
    pos_data_tmp = pos_data1['pos_bags']
    pos_data1 = [i for i in pos_data_tmp]
    # pos_data1 = np.array(pos_data1)

    neg_data1 = loadmat(path + 'neg_bags1.mat')['neg_bags']
    # neg data instance load
    neg_data_tmp = []
    # a =neg_data1.shape
    # b=a[1]
    # 流程一步步运行看一下
    for i in range(neg_data1.shape[1]//25):
        tmp = neg_data1[:, i * 25:i * 25 +25]
        tmp = np.reshape(tmp, (len(tmp), 25))
        # 下采样
        if i % 1 == 0:
            #    i = i + 25
            neg_data_tmp.append(tmp)
    neg_data1 = neg_data_tmp

    # data 2
    pos_data2 = loadmat(path + 'pos_bags2.mat')
    pos_data_tmp = pos_data2['pos_bags']
    pos_data2 = [i for i in pos_data_tmp]
    # pos_data2 = np.array(pos_data2)

    neg_data2 = loadmat(path + 'neg_bags2.mat')['neg_bags']
    neg_data_tmp = []
    for i in range(neg_data2.shape[1]//25):
        tmp = neg_data2[:, i * 25:i * 25 + 25]
        tmp = np.reshape(tmp, (len(tmp), 25))
        # 下采样
        if i % 1 == 0:
            neg_data_tmp.append(tmp)
    neg_data2 = neg_data_tmp

    # data3
    pos_data3 = loadmat(path + 'pos_bags3.mat')
    pos_data_tmp = pos_data3['pos_bags']
    pos_data3 = [i for i in pos_data_tmp]
    # pos_data3 = np.array(pos_data3)

    neg_data3 = loadmat(path + 'neg_bags3.mat')['neg_bags']
    neg_data_tmp = []
    for i in range(neg_data3.shape[1]//25):
        tmp = neg_data3[:, i * 25:i * 25 +25]
        tmp = np.reshape(tmp, (len(tmp), 25))
        #    i = i + 25
        if i % 1 == 0:
            neg_data_tmp.append(tmp)
    neg_data3 = neg_data_tmp

    pos_data = pos_data1 + pos_data3 + pos_data2
    neg_data = neg_data1 + neg_data2 + neg_data3

    pos_data = [i for i in pos_data if len(i)>0]
    pos_data = np.array(pos_data)
    print(pos_data.shape)
    neg_data = np.array(neg_data)
    # 为什么还要删除
    re_band = [0, 1, 2, 3, 68, 69, 70, 71]
    pos_data = np.delete(pos_data, re_band, axis=1)# (44, 64, 25)
    neg_data = np.delete(neg_data, re_band, axis=1)# (12459, 64, 25)

    pos_label = np.array([float(1.0)] * len(pos_data))
    # p_int_label含义是什么
    p_int_label = np.array([[float(1.0)]*25 for i in range(len(pos_data))])
    neg_label = np.array([float(0.0)] * len(neg_data))
    datas = np.concatenate((pos_data,neg_data),axis=0)  # (12503, 64, 25)
    label_sum =np.concatenate((pos_label,neg_label),axis=0)
    datas = datas.transpose((0,2,1))
    inputs = list(zip(datas, label_sum))
    inputs = np.array(inputs)
    return inputs
# validation
def val_data_loader(path: str):
    # data4
    pos_data3 = loadmat(path + 'pos_bags4.mat')
    pos_data_tmp = pos_data3['pos_bags']
    pos_data3 = [i for i in pos_data_tmp]
    neg_data3 = loadmat(path + 'neg_bags4.mat')['neg_bags']
    neg_data_tmp = []
    for i in range(neg_data3.shape[1]//25):
        tmp = neg_data3[:, i * 25:i * 25 +25]
        tmp = np.reshape(tmp, (len(tmp), 25))
        #    i = i + 25
        if i % 1 == 0:
            neg_data_tmp.append(tmp)
    neg_data3 = neg_data_tmp
    pos_data =  pos_data3
    neg_data =  neg_data3
    pos_data = [i for i in pos_data if len(i)>0]
    pos_data = np.array(pos_data)
    print(pos_data.shape)
    neg_data = np.array(neg_data)
    # 为什么还要删除
    re_band = [0, 1, 2, 3, 68, 69, 70, 71]
    pos_data = np.delete(pos_data, re_band, axis=1)# (44, 64, 25)
    neg_data = np.delete(neg_data, re_band, axis=1)# (12459, 64, 25)
    pos_label = np.array([float(1.0)] * len(pos_data))
    neg_label = np.array([float(0.0)] * len(neg_data))
    datas = np.concatenate((pos_data,neg_data),axis=0)  # (12503, 64, 25)
    label_sum =np.concatenate((pos_label,neg_label),axis=0)
    datas = datas.transpose((0,2,1)) # (4595, 25, 64)
    inputs = list(zip(datas, label_sum))
    inputs = np.array(inputs)
    return inputs
# test
def test_data_loader(path: str):
    # data5
    pos_data3 = loadmat(path + 'pos_bags5.mat')
    pos_data_tmp = pos_data3['pos_bags']
    pos_data3 = [i for i in pos_data_tmp]
    neg_data3 = loadmat(path + 'neg_bags5.mat')['neg_bags']
    neg_data_tmp = []
    for i in range(neg_data3.shape[1]//25):
        tmp = neg_data3[:, i * 25:i * 25 +25]
        tmp = np.reshape(tmp, (len(tmp), 25))
        #    i = i + 25
        if i % 1 == 0:
            neg_data_tmp.append(tmp)
    neg_data3 = neg_data_tmp
    pos_data =  pos_data3
    neg_data =  neg_data3
    pos_data = [i for i in pos_data if len(i)>0]
    pos_data = np.array(pos_data)
    print(pos_data.shape)
    neg_data = np.array(neg_data)
    # 为什么还要删除
    re_band = [0, 1, 2, 3, 68, 69, 70, 71]
    pos_data = np.delete(pos_data, re_band, axis=1)# (44, 64, 25)
    neg_data = np.delete(neg_data, re_band, axis=1)# (12459, 64, 25)
    pos_label = np.array([float(1.0)] * len(pos_data))
    neg_label = np.array([float(0.0)] * len(neg_data))
    datas = np.concatenate((pos_data,neg_data),axis=0)  # (12503, 64, 25)
    label_sum =np.concatenate((pos_label,neg_label),axis=0)
    datas = datas.transpose((0,2,1)) # (4433, 25, 64)
    inputs = list(zip(datas, label_sum))
    inputs = np.array(inputs)
    return inputs

def merge():
    # 传入ptyte类型
    # path = os.path.abspath(os.path.join(os.getcwd(), "../../.."))
    datapath = "D:/下载/eldbcompare/data/pea green/"
    print(datapath)
    train_data = train_dataset(datapath)
    val_data = val_data_loader(datapath)
    test_data = test_data_loader(datapath)
    result_data = np.concatenate(( train_data,val_data,test_data), axis=0)
    return result_data

if __name__ == '__main__':
    # 运行程序
    # datapath = './data/pea green/'
    # datapath = 'D:\\Remote_sensing_data_and_codes\\ljm_work1.1\\fc_mil\\data\\pea green\\'
    # # train_dataset= train_dataset(datapath)
    # valdataset = val_data_loader(datapath)
    # test_data = test_data_loader(datapath)
    result_data = merge("pea green")
    print(result_data[0][0].shape)
