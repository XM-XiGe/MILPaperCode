"""
@author: Inki
@contact: inki.yinji@qq.com
@version: Created in 2020 1109, last modified in 2020 1109.
"""

import numpy as np
from sklearn.cluster import MiniBatchKMeans
from sklearn.metrics import euclidean_distances
from MIL import MIL
from DensityPeaks import DensityPeaks
from B2B import B2B
from utils import get_k_cv_idx, kernel_rbf


class SMDP(MIL):
    """
    Non-semi-supervised SMDP.
    """

    def __init__(self, data_path, dc_r=0.2, b2b="ave", n_r=1.0, gamma=1, k=10, bag_space=None):
        """
        The constructor.
        """
        super(SMDP, self).__init__(data_path, bag_space=bag_space)
        self._dc_r = dc_r
        self._b2b = b2b
        self._n_r = n_r
        self._gamma = gamma
        self._k = k

    def __kernel(self, VECTOR):
        """"""

        KERNEL = np.zeros((self.N, self.N))
        for i in range(self.N):
            for j in range(self.N):
                KERNEL[i][j] = KERNEL[j][i] = (0.5 * kernel_rbf(VECTOR[i][0], VECTOR[j][0], gamma=1) +
                                               0.5 * kernel_rbf(VECTOR[i][1], VECTOR[j][1], gamma=1))

        return KERNEL

    def __mapping(self, po_ins, ne_ins):
        """
        获取每个包的映射向量
        """
        VECTOR = []
        po_SHAPE, ne_SHAPE = po_ins.shape[0], ne_ins.shape[0]
        for i in range(self.N):
            bag = self.bag_space[i][0][:, :-1]
            VECTOR.append([euclidean_distances(bag, po_ins).mean(0).reshape(1, po_SHAPE),
                           euclidean_distances(bag, ne_ins).mean(0).reshape(1, ne_SHAPE)])

        return VECTOR

    def get_mapping(self):
        """
        Split mapping instance to training data and test data.
        """

        if self._b2b != "msk":
            dis = B2B(self.data_name, self.bag_space, self._b2b, self._gamma,
                      b2b_save_home="D:/Data/TempData/DisOrSimilarity/",
                      min_max_vector=self.get_min_max()).get_dis()
        else:
            dis = None
        tr_idxes, te_idxes = get_k_cv_idx(self.N, self._k)
        po_lab, ne_lab = np.max(self.bag_lab), np.min(self.bag_lab)

        for i in range(self._k):
            if dis is None:
                tr_lab = self.bag_lab[tr_idxes[i]]
                po_idx, ne_idx = np.where(tr_lab == po_lab)[0], np.where(tr_lab == ne_lab)[0]
                """寻找最负代表性实例"""
                # 获取负包中所有的实例
                ne_ins, _, _ = self.get_sub_ins_space(ne_idx)
                # 计算选取的代表性实例的个数
                k_means = MiniBatchKMeans(n_clusters=10)
                # 选取最负代表性实例
                k_means.fit(ne_ins)
                ne_ins = k_means.cluster_centers_
                """寻找最正代表性实例"""
                po_ins = []
                # 找到每个包中最负代表性实例
                for j in po_idx:
                    # 获取当前包
                    bag = self.bag_space[j][0][:, :-1]
                    # 获取当前包中与最负代表性实例距离最远的实例的索引
                    idx = euclidean_distances(bag, ne_ins).sum(1).argmax()
                    # 记录在最正实例中
                    po_ins.append(bag[idx].tolist())
                po_ins = np.array(po_ins)
                # 找到指定数量的最正实例
                dis = euclidean_distances(po_ins).sum(0)
                max_dis_idx = np.argsort(dis)[::-1]
                po_ins = po_ins[max_dis_idx[:10]]
                # 获取双重空间表示
                VECTOR = self.__mapping(po_ins, ne_ins)
                """计算核矩阵"""
                dis = self.__kernel(VECTOR)
            dp = DensityPeaks(dis, tr_idxes[i], self._dc_r)
            dp.cluster(int(self._n_r * len(tr_idxes[i])))
            representatives = dp.centers
            V = dis[:, representatives]
            yield V[tr_idxes[i]], self.bag_lab[tr_idxes[i]], V[te_idxes[i]], self.bag_lab[te_idxes[i]], None
