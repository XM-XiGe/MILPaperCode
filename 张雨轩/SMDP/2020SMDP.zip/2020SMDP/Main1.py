"""
@author: Inki
@contact: inki.yinji@qq.com
@version: Created in 2020 0907 1601, last modified in 2021 0415.
"""

import numpy as np
import warnings
import time
from SMDP import SMDP
from BagLoader import BagLoader
from Classifier import Classifier
warnings.filterwarnings('ignore')


def test_10cv():
    """
    """
    data_path = "D:/OneDrive/Files/Code/Data/MIL/Drug/musk1+.mat"
    data_list = [
                 # "D:/Data/OneDrive/Code/MIL1/Data/Drug/musk1+.mat",
                 # "D:/Data/OneDrive/Code/MIL1/Data/Drug/musk2+.mat",
                 # "D:/Data/OneDrive/Code/MIL1/Data/Image/elephant+.mat",
                 # "D:/Data/OneDrive/Code/MIL1/Data/Image/fox+.mat",
                 # "D:/Data/OneDrive/Code/MIL1/Data/Image/tiger+.mat",
                 # "D:/Data/OneDrive/Code/MIL1/Data/Web/web1+.mat",
                 # "D:/Data/OneDrive/Code/MIL1/Data/Web/web2+.mat",
                 # "D:/Data/OneDrive/Code/MIL1/Data/Web/web3+.mat",
                 # "D:/Data/OneDrive/Code/MIL1/Data/Web/web4+.mat",
                 # "D:/Data/OneDrive/Code/MIL1/Data/Web/web5+.mat",
                 # "D:/Data/OneDrive/Code/MIL1/Data/Web/web6+.mat",
                 # "D:/Data/OneDrive/Code/MIL1/Data/Web/web7+.mat",
                 # "D:/Data/OneDrive/Code/MIL1/Data/Web/web8+.mat",
                 # "D:/Data/OneDrive/Code/MIL1/Data/Web/web9+.mat",
                 # "D:/Data/OneDrive/Code/MIL1/Data/Text/alt_atheism.mat",
                 # "D:/Data/OneDrive/Code/MIL1/Data/Text/comp_graphics.mat",
                 # "D:/Data/OneDrive/Code/MIL1/Data/Text/comp_os_ms-windows_misc.mat",
                 # "D:/Data/OneDrive/Code/MIL1/Data/Text/comp_sys_ibm_pc_hardware.mat",
                 # "D:/Data/OneDrive/Code/MIL1/Data/Text/comp_sys_mac_hardware.mat",
                 # "D:/Data/OneDrive/Code/MIL1/Data/Text/comp_windows_x.mat",
                 # "D:/Data/OneDrive/Code/MIL1/Data/Text/misc_forsale.mat",
                 # "D:/Data/OneDrive/Code/MIL1/Data/Text/rec_autos.mat",
                 # "D:/Data/OneDrive/Code/MIL1/Data/Text/rec_motorcycles.mat",
                 # "D:/Data/OneDrive/Code/MIL1/Data/Text/rec_sport_baseball.mat",
                 # "D:/Data/OneDrive/Code/MIL1/Data/Text/rec_sport_hockey.mat",
                 # "D:/Data/OneDrive/Code/MIL1/Data/Text/sci_crypt.mat",
                 # "D:/Data/OneDrive/Code/MIL1/Data/Text/sci_electronics.mat",
                 # "D:/Data/OneDrive/Code/MIL1/Data/Text/sci_med.mat",
                 # "D:/Data/OneDrive/Code/MIL1/Data/Text/sci_religion_christian.mat",
                 # "D:/Data/OneDrive/Code/MIL1/Data/Text/sci_space.mat",
                 # "D:/Data/OneDrive/Code/MIL1/Data/Text/talk_politics_guns.mat",
                 # "D:/Data/OneDrive/Code/MIL1/Data/Text/talk_politics_mideast.mat",
                 # "D:/Data/OneDrive/Code/MIL1/Data/Text/talk_politics_misc.mat",
                 # "D:/Data/OneDrive/Code/MIL1/Data/Text/talk_religion_misc.mat",
                 # "D:/Data/OneDrive/Code/MIL1/Data/Mutagenesis/mutagenesis1.mat",
                 "D:/Data/OneDrive/Code/MIL1/Data/Mutagenesis/mutagenesis2.mat",
                 ]

    """======================================================="""
    loops = 5
    # tr_f1_k, tr_acc_k, tr_roc_k = np.zeros(loops), np.zeros(loops), np.zeros(loops)
    # tr_f1_s, tr_acc_s, tr_roc_s = np.zeros(loops), np.zeros(loops), np.zeros(loops)
    # tr_f1_j, tr_acc_j, tr_roc_j = np.zeros(loops), np.zeros(loops), np.zeros(loops)
    te_f1_k, te_acc_k, te_roc_k = np.zeros(loops), np.zeros(loops), np.zeros(loops)
    te_f1_s, te_acc_s, te_roc_s = np.zeros(loops), np.zeros(loops), np.zeros(loops)
    te_f1_j, te_acc_j, te_roc_j = np.zeros(loops), np.zeros(loops), np.zeros(loops)

    # for po_label in range(10):
    #     bag_space = BagLoader(seed=1, po_label=po_label, data_type="fashion_mnist", data_path="D:/Data/").bag_space
    mil = SMDP(data_path, bag_space=None)
    for i in range(loops):
        classifier = Classifier(["knn", "svm", "j48"], ["f1_score", "acc", "roc"])
        s_t = time.time()
        data_iter = mil.get_mapping()
        te_per = classifier.test(data_iter)
        te_f1_k[i], te_acc_k[i], te_roc_k[i] = te_per["knn"][0], te_per["knn"][1], te_per["knn"][2]
        te_f1_s[i], te_acc_s[i], te_roc_s[i] = te_per["svm"][0], te_per["svm"][1], te_per["svm"][2]
        te_f1_j[i], te_acc_j[i], te_roc_j[i] = te_per["j48"][0], te_per["j48"][1], te_per["j48"][2]
        print("%.4lf, %.4lf, %.4lf" % (te_acc_k[i], te_acc_s[i], te_acc_j[i]))


if __name__ == '__main__':
    s_t = time.time()
    test_10cv()
    print(1000 * (time.time() - s_t))
