import numpy as np
from SMDP import SMDP


def test_10cv():
    """
    """
    po_label = 9
    ct = "svm"
    file_name = "D:/OneDrive/Files/Code/Data/MIL/Drug/musk1+.mat"
    # file_name = "fashion_mnist" + str(po_label) + ".none"

    print("=================================================")
    print("File name: %s" % (file_name.split(".")[-2].split("/")[-1]))
    # print("knn-f1  std     knn-acc  std    knn-roc  std    svm-f1  std     svm-acc  std    svm-roc  std    "
    #       "j48-f1  std     j48-acc  std    j48-roc  std")
    """======================================================="""
    from BagLoader import BagLoader
    bag_space = BagLoader(seed=1, po_label=po_label, data_type="fashion_mnist", data_path="D:/Data/").bag_space
    for b2b in ["ave", "csd", "mik", "sim", "msk"]:
        print("& %s                                     " % b2b.upper(), end="")
        for n_r in np.arange(0.1, 1, 0.1):
            loops = 5
            te_f1_k, te_acc_k, te_roc_k = np.zeros(loops), np.zeros(loops), np.zeros(loops)

            mil = SMDP(file_name, b2b=b2b, dc_r=0.2, n_r=n_r, bag_space=bag_space)
            from Classifier import Classifier
            for i in range(loops):

                classifier = Classifier(["knn", "svm", "j48"], ["f1_score", "acc", "roc"])
                data_iter = mil.get_mapping()
                te_per = classifier.test(data_iter)
                te_f1_k[i], te_acc_k[i], te_roc_k[i] = te_per[ct][0], te_per[ct][1], te_per[ct][2]

            # if n_r == 0.9:
            #     print("& $%.3lf\pm%.3lf$\\\\" % (np.sum(te_f1_k) / loops, np.std(te_f1_k)))
            # else:
            #     print("& $%.3lf\pm%.3lf$                          " % (np.sum(te_f1_k) / loops, np.std(te_f1_k)),
            #           end="")
            if n_r == 0.9:
                print("& $%.2lf_{\pm %.2lf}$\\\\" % (np.sum(te_f1_k) / loops * 100, np.std(te_f1_k) * 100))
            else:
                print("& $%.2lf_{\pm %.2lf}$                          " % (np.sum(te_f1_k) / loops * 100, np.std(te_f1_k) * 100),
                      end="")


if __name__ == '__main__':
    import time
    s_time = time.time()
    test_10cv()
    print((time.time() - s_time) * 1000)
