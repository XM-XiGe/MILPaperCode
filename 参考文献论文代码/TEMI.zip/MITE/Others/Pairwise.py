# @Time : 2022/3/24 18:05
# @Author: ZWX
# @Email: 935721546@qq.com
# @File : Pairwise.py

import matplotlib.pyplot as plt
import numpy as np

plt.figure(figsize=(10, 10))
plt.rc('font', family='Times New Roman')
distance_based = np.array([0.842, 0.811, 0.805, 0.577, 0.691, 0.803, 0.880, 0.598, 0.564,
                           0.554, 0.572, 0.534, 0.566, 0.568, 0.602, 0.508, 0.550, 0.534, 0.552,
                           0.560, 0.584, 0.606, 0.564, 0.578, 0.562, 0.590, 0.564, 0.534, 0.500,
                           0.818, 0.818, 0.815, 0.804, 0.775, 0.802, 0.576, 0.640, 0.644])

encoding_based = np.array([0.862, 0.824, 0.887, 0.675, 0.863, 0.864, 0.785, 0.692, 0.856,
                           0.878, 0.818, 0.718, 0.836, 0.826, 0.842, 0.740, 0.806, 0.850, 0.832,
                           0.938, 0.854, 0.944, 0.870, 0.764, 0.872, 0.812, 0.873, 0.758, 0.742,
                           0.831, 0.838, 0.829, 0.865, 0.845, 0.862, 0.760, 0.782, 0.796])

StableMIL = np.array([0.848, 0.822, 0.765, 0.536, 0.710, 0.838, 0.840, 0.545, 0.544,
                      0.520, 0.512, 0.498, 0.518, 0.542, 0.524, 0.514, 0.540, 0.560, 0.526,
                      0.500, 0.534, 0.530, 0.520, 0.552, 0.524, 0.486, 0.550, 0.564, 0.536,
                      0.822, 0.805, 0.807, 0.722, 0.781, 0.733, 0.620, 0.590, 0.549])

plt.xticks([0.4, 0.6, 0.8, 1.0])
plt.yticks([0.4, 0.6, 0.8, 1.0])
plt.xlabel('Accuracy of DBE', fontsize=24)
plt.ylabel('Accuracy of StableMIL', fontsize=24)
# plt.ylabel('Tri-perspective embedding', fontsize=24)
# plt.scatter(distance_based, StableMIL, s=np.pi * 6 ** 2, marker='^')
plt.scatter(distance_based, encoding_based, s=np.pi * 6 ** 2, marker='^')
plt.tick_params(labelsize=24)
plt.plot([0.4, 1], [0.4, 1], color='r', lw=2)
plt.subplots_adjust(left=0.09, right=0.996, top=0.955, bottom=0.08)
plt.show()

