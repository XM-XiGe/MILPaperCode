import torch
from torch.utils.data import DataLoader, Subset
from ANData import MyDataSetBag
from ANutils import get_index_random
import torch.optim as optim
import numpy as np
import time
from sklearn.metrics import precision_score, recall_score, f1_score, accuracy_score
from Models import Attention


def test_on_10cv(dataset, para_k=10, lr=0.0001, ins_len=166, total_epoch=100):
    # dataset_name = dataset.split('/')[-1].split('.')[0]
    # 第i次cv
    cv10_acc_list = []
    cv10_f1_list = []
    cv10_recall_list = []
    cv10_precision_list = []
    for cv_idx in range(1):
        train_index_list, test_index_list = get_index_random(num_bags=len(AllDataSet), para_k=para_k)
        # 第i轮cv
        cv_acc_list = []
        cv_f1_list = []
        cv_recall_list = []
        cv_precision_list = []
        for i in range(para_k):
            TrainDataSet = Subset(dataset, train_index_list[i])
            TestDataSet = Subset(dataset, test_index_list[i])

            train_loader = DataLoader(TrainDataSet, shuffle=False, batch_size=1)
            test_loader = DataLoader(TestDataSet, shuffle=False, batch_size=1)

            # 定义损失函数
            class MILoss(torch.nn.Module):
                def __init__(self):
                    super(MILoss, self).__init__()

                def forward(self, pred, true):
                    prob = pred.squeeze()
                    label = true.squeeze()
                    loss = None
                    if label.numpy() == 0:
                        loss = prob - label
                    elif label.numpy() == 1:
                        loss = label - prob

                    return loss

            model = Attention(num_att=ins_len, D=len(AllDataSet))

            criterion = torch.nn.CrossEntropyLoss()  # 与tensorflow不同，此处交叉熵损失先会将输入softmax
            optimizer = optim.Adam(model.parameters(), lr=lr)

            def train_for_epoch(epoch, i):
                model.train()
                running_loss = 0.0
                for batch_idx, data in enumerate(train_loader, 0):
                    inputs, target = data
                    target = target.long()
                    bag = inputs

                    optimizer.zero_grad()

                    outputs, vec = model(bag)
                    loss = criterion(outputs, target)
                    loss.backward()
                    optimizer.step()

                    running_loss += loss.item()

                # if (epoch + 1) % 10 == 0:
                # print(' %d: %d -th CV ,%d -th epoch loss: %.3f' % (
                #     cv_idx + 1, i + 1, epoch + 1, running_loss / len(TrainDataSet)),
                #       end=' ### ')

            def test_for_epoch(epoch):
                y_true = []
                y_pred = []
                with torch.no_grad():
                    for data in test_loader:
                        inputs, label = data
                        bag = inputs
                        outputs, vec = model(bag)
                        _, pred = torch.max(outputs.data, dim=1)  # 返回最大值及其索引
                        y_true.append(label.item())
                        y_pred.append(pred.item())
                acc = accuracy_score(y_true, y_pred)
                # f1 = f1_score(y_true, y_pred)
                # recall = recall_score(y_true, y_pred)
                # precision = precision_score(y_true, y_pred)
                # print('Test Acc: %.2f | F1: %.2f | Recall: %.2f | Presision: %.2f' % (acc, f1, recall, precision))
                return acc

            # 单次10CV中的一次，即1次run
            def train_for_one_cv(i):
                acc_list = []
                f1_list = []
                recall_list = []
                precision_list = []
                for epoch in range(total_epoch):  # 记录下每个epoch的值，求最大
                    train_for_epoch(epoch, i)
                    acc = test_for_epoch(epoch)
                    acc_list.append(acc)
                    # f1_list.append(f1)
                    # recall_list.append(recall)
                    # precision_list.append(precision)
                return np.max(acc_list)# , f1_list[int(np.argmax(acc_list))], recall_list[int(np.argmax(acc_list))], \
                       # precision_list[int(np.argmax(acc_list))]

            acc = train_for_one_cv(i)
            cv_acc_list.append(acc)
            # cv_f1_list.append(f1)
            # cv_recall_list.append(recall)
            # cv_precision_list.append(precision)

        cv10_acc_list.append(np.mean(cv_acc_list))
        # cv10_f1_list.append(np.mean(cv_f1_list))
        # cv10_recall_list.append(np.mean(cv_recall_list))
        # cv10_precision_list.append(np.mean(cv_precision_list))

    return np.mean(cv10_acc_list) * 100, np.std(cv10_acc_list) * 100, \
        # np.mean(cv10_f1_list) * 100, np.std(cv10_f1_list) * 100, \
    # np.mean(cv10_recall_list) * 100, np.std(cv10_recall_list) * 100, \
    # np.mean(cv10_precision_list) * 100, np.std(cv10_precision_list) * 100


if __name__ == '__main__':
    # lr = 0.001
    # total_epoch = 100
    # path = '../Data/Benchmark/musk1+.mat'
    # dr = None
    #
    # AllDataSet = MyDataSetBag(path=path, dr=dr)
    # ins_len = len(AllDataSet[0][0][0])
    #
    # start = time.process_time()
    #
    # acc, acc_std, \
    # f1, f1_std, \
    # recall, recall_std, \
    # precision, precision_std = test_on_10cv(dataset=AllDataSet, para_k=10, lr=lr, ins_len=ins_len,
    #                                         total_epoch=total_epoch)
    # # print(path.split('/')[-1].split('.')[0] + ' :10次10cv的均值为:{}, 标准差为{}'.format(mean, std))
    #
    # print('Acc: $%.1f_{\\pm%.1f}$' % (float(acc), float(acc_std)))
    # print('F1: $%.1f_{\\pm%.1f}$' % (float(f1), float(f1_std)))
    # print('Recall: $%.1f_{\\pm%.1f}$' % (float(recall), float(recall_std)))
    # print('Precision: $%.1f_{\\pm%.1f}$' % (float(precision), float(precision_std)))
    #
    # end = time.process_time()
    # print('Time Cost:', end - start)

    path_list = ['../Data/Benchmark/musk1+.mat',
                 '../Data/Benchmark/musk2+.mat',
                 '../Data/Benchmark/elephant+.mat',
                 '../Data/Benchmark/fox+.mat',
                 '../Data/Benchmark/tiger+.mat',
                 '../Data/Text(sparse)/normalized/alt_atheism+.mat',
                 '../Data/Text(sparse)/normalized/comp_os_ms-windows_misc+.mat',
                 '../Data/Text(sparse)/normalized/comp_sys_mac_hardware+.mat',
                 '../Data/Text(sparse)/normalized/misc_forsale+.mat',
                 '../Data/Text(sparse)/normalized/rec_motorcycles+.mat',
                 '../Data/Text(sparse)/normalized/rec_sport_hockey+.mat',
                 '../Data/Text(sparse)/normalized/sci_med+.mat',
                 '../Data/Text(sparse)/normalized/sci_religion_christian+.mat',
                 '../Data/Text(sparse)/normalized/talk_politics_guns+.mat',
                 '../Data/Text(sparse)/normalized/talk_politics_misc+.mat']
    for path in path_list:
        start = time.process_time()
        AllDataSet = MyDataSetBag(path=path, dr=None)
        ins_len = len(AllDataSet[0][0][0])
        acc, acc_std = test_on_10cv(dataset=AllDataSet, para_k=10, lr=0.001, ins_len=ins_len,
                                                total_epoch=100)
        print(path.split('/')[-1], end=' ')
        print('Time cost of one 10CV:', time.process_time() - start)

# musk1: lr=0.001, epoch=150, acc=91.9, std=2.95 论文中89.2
# musk2: lr=0.001, epoch=150, acc=91.0, std=2.14 论文中85.8

# News.aa: lr=0.001, epoch=20, acc=80.6 std=1.68
# News.cg: lr=0.001, epoch=20, acc=74.6 std=2.19 
# News.co: lr=0.001, epoch=20, acc=68.5 std=1.62
# News.csi: lr=0.001, epoch=20, acc=76.1 std=1.3
# News.csm: lr=0.001, epoch=20, acc=78.3 std=1.84
# News.cw: lr=0.001, epoch=20, acc=73.2 std=1.88
# News.mf: lr=0.001, epoch=20, acc=66.4 std=2.87
# News.ra: lr=0.001, epoch=20, acc=73.8 std=1.08
# News.rm: lr=0.001, epoch=20, acc=75.0 std=3.19
# News.rsb: lr=0.001, epoch=20, acc=76.9 std=1.13
# News.rsh: lr=0.001, epoch=20, acc=78.6 std=3.13
# News.sc: lr=0.001, epoch=20, acc=77.5 std=2.58
# News.se: lr=0.001, epoch=20, acc=70.5 std=1.43
# News.sm: lr=0.001, epoch=20, acc=76.5 std=2.24
# News.src: lr=0.001, epoch=20, acc=77.5 std=2.87
# News.ss: lr=0.001, epoch=20, acc=81.1 std=1.22
# News.tpg: lr=0.001, epoch=20, acc=78.6 std=1.74
# News.tpmd: lr=0.001, epoch=20, acc=82.3 std=1.79
# News.tpmc: lr=0.001, epoch=20, acc=80.8 std=1.6
# News.trm: lr=0.001, epoch=20, acc=65.0 std=2.14
#

# musk1+.mat Time cost of one 10CV: 1804.0625
# musk2+.mat Time cost of one 10CV: 2504.109375
# elephant+.mat Time cost of one 10CV: 5141.3125
# fox+.mat Time cost of one 10CV: 4956.140625
# tiger+.mat Time cost of one 10CV: 5105.84375
# alt_atheism+.mat Time cost of one 10CV: 1690.90625
# comp_os_ms-windows_misc+.mat Time cost of one 10CV: 1893.265625
# comp_sys_mac_hardware+.mat Time cost of one 10CV: 1743.78125
# misc_forsale+.mat Time cost of one 10CV: 1864.078125
# rec_motorcycles+.mat Time cost of one 10CV: 1689.9375
# rec_sport_hockey+.mat Time cost of one 10CV: 1576.46875
# sci_med+.mat Time cost of one 10CV: 1591.34375
# sci_religion_christian+.mat Time cost of one 10CV: 1621.109375
# talk_politics_guns+.mat Time cost of one 10CV: 1550.0
# talk_politics_misc+.mat Time cost of one 10CV: 1593.078125