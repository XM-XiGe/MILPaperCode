import torch
from torch import nn
import torch.nn.functional as func_nn


class Attention(nn.Module):
    def __init__(self, num_att, D):
        super(Attention, self).__init__()
        self.num_att = num_att
        self.L = 500
        self.D = D
        self.K = 1

        self.feature_extractor_part = nn.Sequential(
            nn.Linear(self.num_att, self.L),
            nn.ReLU(),
        )

        self.attention = nn.Sequential(
            nn.Linear(self.L, self.D),
            nn.Tanh(),
            nn.Linear(self.D, self.K)
        )

        self.classifier = nn.Sequential(
            nn.Linear(self.L*self.K, 2),
            nn.Sigmoid()
        )

    def forward(self, x):
        x = x.float()
        x = x.squeeze(0)

        H = self.feature_extractor_part(x)

        A = self.attention(H)
        A = torch.transpose(A, 1, 0)
        A = func_nn.softmax(A, dim=1)
        M = torch.mm(A, H)

        Y_prob = self.classifier(M)
        # print(Y_prob)
        # exit(0)
        return Y_prob , M
