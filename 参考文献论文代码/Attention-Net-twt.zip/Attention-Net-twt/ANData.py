from torch.utils.data import Dataset, DataLoader, Subset
from ANutils import load_data, get_index, load_data_bag
import numpy as np


class MyDataSet(Dataset):
    def __init__(self, path='./MILFrame/data/benchmark/musk1+.mat', sparsity=0.8):
        self.data, self.labels = load_data(path=path, sparsity=sparsity)

    def __getitem__(self, idx):
        return self.data[idx], self.labels[idx]

    def __len__(self):
        return len(self.labels)


# 不做包邻居，只返回每个包
class MyDataSetBag(Dataset):
    def __init__(self, path='./MILFrame/data/benchmark/musk1+.mat', dr=None):
        self.data, self.labels = load_data_bag(path=path, dr=dr)

    def __getitem__(self, idx):
        return self.data[idx], self.labels[idx]

    def __len__(self):
        return len(self.labels)


if __name__ == '__main__':
    AllDataSet = MyDataSet(path='./MILFrame/data/benchmark/musk1+.mat', sparsity=0.8)
    train_idx_list, test_idx_list = get_index(num_bags=len(AllDataSet), para_k=10, seed=1)

    trainDataSet = Subset(AllDataSet, train_idx_list[0])
    testDataSet = Subset(AllDataSet, test_idx_list[0])

    train_loader = DataLoader(dataset=trainDataSet,
                              batch_size=1,
                              shuffle=False,
                              num_workers=0)

    test_loader = DataLoader(dataset=testDataSet,
                             batch_size=1,
                             shuffle=False,
                             num_workers=0)

    for i, data in enumerate(train_loader):
        self_neighbors, label = data
        self = self_neighbors[0]
        neighbors = self_neighbors[1]
        print(self.shape, end=' ')
        print(len(neighbors))
