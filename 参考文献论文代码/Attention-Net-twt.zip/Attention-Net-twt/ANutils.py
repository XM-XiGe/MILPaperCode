import numpy as np
from MILFrame.MIL import MIL
from tqdm import tqdm
import os
from sklearn.decomposition import PCA


# np.set_printoptions(threshold=np.inf)
def get_index(num_bags=92, para_k=10, seed=1):
    """
    Get the training set index and test set index.
    :param
        para_k:
            The number of k-th fold.
    :return
        ret_tr_idx:
            The training set index, and its type is dict.
        ret_te_idx:
            The test set index, and its type is dict.
    """
    np.random.seed(seed)
    temp_rand_idx = np.random.permutation(num_bags)

    temp_fold = int(np.ceil(num_bags / para_k))
    ret_tr_idx = {}
    ret_te_idx = {}
    for i in range(para_k):
        temp_tr_idx = temp_rand_idx[0: i * temp_fold].tolist()
        temp_tr_idx.extend(temp_rand_idx[(i + 1) * temp_fold:])
        ret_tr_idx[i] = temp_tr_idx
        ret_te_idx[i] = temp_rand_idx[i * temp_fold: (i + 1) * temp_fold].tolist()
    return ret_tr_idx, ret_te_idx


def get_index_random(num_bags=92, para_k=10):
    temp_rand_idx = np.random.permutation(num_bags)

    temp_fold = int(np.ceil(num_bags / para_k))
    ret_tr_idx = {}
    ret_te_idx = {}
    for i in range(para_k):
        temp_tr_idx = temp_rand_idx[0: i * temp_fold].tolist()
        temp_tr_idx.extend(temp_rand_idx[(i + 1) * temp_fold:])
        ret_tr_idx[i] = temp_tr_idx
        ret_te_idx[i] = temp_rand_idx[i * temp_fold: (i + 1) * temp_fold].tolist()
    return ret_tr_idx, ret_te_idx


def ave_hausdorff(i, bag_i, j, bag_j):
    sum_ = 0
    if i == j:
        return sum_
    matrix_i = bag_i
    matrix_j = bag_j
    for i_ins in matrix_i:
        dis_to_i = []
        for j_ins in matrix_j:
            dis_to_i.append(dis_between_ins(i_ins, j_ins))
        sum_ = sum_ + min(dis_to_i)
    for j_ins in matrix_j:
        dis_to_j = []
        for i_ins in matrix_i:
            dis_to_j.append(dis_between_ins(j_ins, i_ins))
        sum_ = sum_ + min(dis_to_j)
    return sum_ / (len(matrix_i) + len(matrix_j))


def dis_between_ins(ins1, ins2):
    return np.sqrt(np.sum(np.power((ins1 - ins2), 2)))


# 在adj中，按照行找邻居包
def find_neighbor_id(i, line):
    neighbors = []
    for idx, num in enumerate(line):
        if idx != i and num == 1:
            neighbors.append(idx)
    return np.array(neighbors)



# 返回包与其邻居作为数据集
def load_data(path='./MILFrame/data/benchmark/musk1+.mat', sparsity=0.5):
    dataset_name = path.split('/')[-1].split('.')[0]
    mil = MIL(para_path=path)
    dis_file_name = dataset_name + '.npy'
    dis_file_dir = 'Distance/'
    dis_file_path = dis_file_dir + dis_file_name

    # 得到两两包之间的距离矩阵，第一次计算会将其存下，方便后续直接使用
    if os.path.exists(dis_file_path):
        print('*' * 20 + 'Load Precomputed Distance' + '*' * 20)
        dis_matrix = np.load(dis_file_path)
    else:
        dis_matrix = np.zeros((mil.num_bags, mil.num_bags))
        for i in tqdm(range(mil.num_bags)):
            for j in range(mil.num_bags):
                dis_matrix[i, j] = ave_hausdorff(i, mil.bags[i, 0][:, :-1], j, mil.bags[j, 0][:, :-1])
    np.save(dis_file_path, dis_matrix)

    # 根据参数sparsity得到adj
    sorted_dis = np.sort(dis_matrix, axis=None)
    top_num = int(mil.num_bags ** 2 * (1 - sparsity))
    threshold = sorted_dis[top_num]
    adj = np.where(dis_matrix <= threshold, 1, 0)
    # 根据adj得到每个包的邻居id
    neighbor_ids = []
    for i, line in enumerate(adj):
        neighbor_id = find_neighbor_id(i, line)
        neighbor_ids.append(neighbor_id)
    # for i, idx in enumerate(neighbor_ids):
    #     print(i, end=' ')
    #     print(idx)
    bags = []  # 得到将包内与其他示例距离和最小的示例放于0位置的新包
    for i in range(mil.num_bags):
        bags.append(sort_bag(mil.bags[i, 0][:, :-1]))

    self_neighbors = []  # self_neighbors[bag_id][neighbor_ids]
    for i, ids in enumerate(neighbor_ids):
        self_neighbor = [bags[i]]
        for idx in ids:
            self_neighbor.append(bags[idx])  # self_neighbor中第一个包为要聚合周围邻居的包
        # self_neighbor = [bags[i], neighbor]
        self_neighbors.append(self_neighbor)

    # for i in self_neighbors:
    #     print(len(i))
    lables = np.where(mil.bags_label < 0, 0, mil.bags_label)
    return self_neighbors, lables


# 只返回包作为数据集
def load_data_bag(path='./MILFrame/data/benchmark/musk1+.mat', dr=None):
    if dr is None:
        mil = MIL(para_path=path)
        bags = []
        for i in range(mil.num_bags):
            bags.append(mil.bags[i, 0][:, :-1])
        lables = np.where(mil.bags_label < 0, 0, mil.bags_label)
        return bags, lables
    else:
        print('*' * 20 + 'Dimensionality reduction' + 20 * '*')
        mil = MIL(para_path=path)
        lables = np.where(mil.bags_label < 0, 0, mil.bags_label)
        pca = PCA(n_components=100)
        new_ins = pca.fit_transform(mil.ins)
        bags = []
        for i in range(mil.num_bags):
            bag = new_ins[mil.ins_idx[i]: mil.ins_idx[i + 1]]
            bags.append(bag)
        sorted_bags = []
        for bag in bags:
            sorted_bags.append(bag)
        return sorted_bags, lables


# 返回多分类的包和标签
def load_multi_class_bag(path):
    mil = MIL(para_path=path)
    bags = []
    for i in range(mil.num_bags):
        bags.append(mil.bags[i, 0][:, :-1])
    lables = mil.bags_label
    return np.array(bags, dtype=object), np.array(lables)


if __name__ == '__main__':
    bags, labels = load_data_bag(path='./MILFrame/data/newsgroups/alt_atheism+.mat', dr=100)
    # bags, labels = load_data_bag(path='E:/Data/MI/datasets/image-2000.mat')
    print(bags[0].shape)


