import torch.nn as nn
import torch.nn.functional as func_nn
import warnings
from torch.utils.data import Dataset, DataLoader, Subset
from scipy.io import loadmat
import torch
import torch.optim as optim
from sklearn.metrics import f1_score, accuracy_score
import numpy as np
from utils import get_index
import time

warnings.filterwarnings('ignore')


class MnistBagsDateset(Dataset):
    def __init__(self, path):
        self.data = loadmat(path)['data']

    def __getitem__(self, idx):
        return self.data[idx][0], self.data[idx][1].tolist()[0][0]

    def __len__(self):
        return len(self.data)


# Convolve the pictures to instances
class MyConv(nn.Module):
    def __init__(self):
        super(MyConv, self).__init__()
        self.L = 500
        self.D = 128
        self.K = 1

        self.feature_extractor_part1 = nn.Sequential(
            nn.Conv2d(1, 20, kernel_size=5),
            nn.ReLU(),
            nn.MaxPool2d(2, stride=2),
            nn.Conv2d(20, 50, kernel_size=5),
            nn.ReLU(),
            nn.MaxPool2d(2, stride=2)
        )

        self.feature_extractor_part2 = nn.Sequential(
            nn.Linear(50 * 4 * 4, self.L),
            nn.Dropout(),
            nn.ReLU(),
        )

    def forward(self, x):
        x = torch.unsqueeze(x, dim=1)
        H = self.feature_extractor_part1(x)
        H = H.view(-1, 50 * 4 * 4)
        H = self.feature_extractor_part2(H)  # NxL
        return H


class Attention(nn.Module):
    def __init__(self, num_att=500, D=100):
        super(Attention, self).__init__()
        self.num_att = num_att
        self.L = 500
        self.D = D
        self.K = 1
        self.conv = MyConv()
        self.feature_extractor_part = nn.Sequential(
            nn.Linear(self.num_att, self.L),
            nn.ReLU(),
        )

        self.attention = nn.Sequential(
            nn.Linear(self.L, self.D),
            nn.Tanh(),
            nn.Linear(self.D, self.K)
        )

    def forward(self, x):
        x = self.conv(x)

        H = self.feature_extractor_part(x)

        A = self.attention(H)
        A = torch.transpose(A, 1, 0)
        A = func_nn.softmax(A, dim=1)
        M = torch.mm(A, H)
        return M


class GatedAttention(nn.Module):
    def __init__(self, num_att=500, D=200):
        super(GatedAttention, self).__init__()
        self.num_att = num_att
        self.L = 500
        self.D = D
        self.K = 1
        self.conv = MyConv()
        self.feature_extractor_part = nn.Sequential(
            nn.Linear(self.num_att, self.L),
            nn.ReLU(),
        )

        self.attention_V = nn.Sequential(
            nn.Linear(self.L, self.D),
            nn.Tanh()
        )

        self.attention_U = nn.Sequential(
            nn.Linear(self.L, self.D),
            nn.Sigmoid()
        )

        self.attention_weights = nn.Linear(self.D, self.K)

        self.classifier = nn.Sequential(
            nn.Linear(self.L*self.K, 1),
            nn.Sigmoid()
        )

    def forward(self, x):
        x = self.conv(x)
        H = self.feature_extractor_part(x)  # NxL

        A_V = self.attention_V(H)  # NxD
        A_U = self.attention_U(H)  # NxD
        A = self.attention_weights(A_V * A_U) # element wise multiplication # NxK
        A = torch.transpose(A, 1, 0)  # KxN
        A = func_nn.softmax(A, dim=1)  # softmax over N

        M = torch.mm(A, H)  # KxL

        return M


def run(train_path, test_path, epochs, lr, method):
    trainDataset = MnistBagsDateset(path=train_path)
    testDataset = MnistBagsDateset(path=test_path)

    trainLoader = DataLoader(trainDataset, shuffle=False, batch_size=1)
    testLoader = DataLoader(testDataset, shuffle=False, batch_size=1)
    model = None
    if method == 'a':
        model = Attention()
    elif method == 'g':
        model = GatedAttention()
    criterion = torch.nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=lr)
    # 训练一轮，测试一次
    acc_list = []
    # f1_list = []
    for epoch in range(epochs):
        # training phase
        model.train()
        running_loss = 0.0
        # total = 0.0
        # correct = 0.0
        y_true, y_pred, acc = [], [], 0
        for batch_idx, data in enumerate(trainLoader, 0):
            inputs, target = data
            target = target.long()
            y_true.append(target.detach().numpy())
            inputs = inputs.squeeze(0)
            outputs = model(inputs)
            _, pred = torch.max(outputs.data, dim=1)  # 返回最大值及其索引
            y_pred.append(pred.detach().numpy())
            # total += target.size(0)
            # correct += (pred == target).sum().item()
            # acc = correct / total
            acc = accuracy_score(y_true, y_pred)
            loss = criterion(outputs, target)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            running_loss += loss.item()

        print('%2d -th epoch: Train: loss: %.3f, acc: %.2f:' % (epoch + 1, running_loss / 100, acc * 100), end=' # ')
        # testing phase
        correct = 0
        total = 0
        y_true, y_pred = [], []
        with torch.no_grad():
            model.eval()
            y_pred = []
            y_true = []
            for data in testLoader:
                inputs, labels = data
                y_true.append(labels.item())
                inputs = inputs.squeeze(0)
                outputs = model(inputs)

                _, pred = torch.max(outputs.data, dim=1)  # 返回最大值及其索引
                y_pred.append(pred.item())
                # total += labels.size(0)
                # correct += (pred == labels).sum().item()
                # acc = correct / total
        acc = accuracy_score(y_true, y_pred)
        # f1 = f1_score(y_true, y_pred, zero_division=0)
        print('Test: acc: %.6f' % acc)
        acc_list.append(acc)
        # f1_list.append(f1)
        if acc == 1:
            break
    return np.max(acc_list)


if __name__ == '__main__':
    start = time.process_time()
    train_path = '../../Data/Mnist-bags/Multi/100/mnist_100_train.mat'
    test_path = '../../Data/Mnist-bags/Multi/100/mnist_100_test.mat'
    dataset_name = train_path.split('/')[-1].split('.')[0][:8]
    epochs = 100
    lr = 0.0001
    method = 'a'

    acc = run(train_path, test_path, epochs, lr, method)
    print(dataset_name)
    print('epochs: ', epochs)
    print('lr:', lr)
    print('method:', method)
    print('acc: %6f' % acc)
    print('Time cost:', time.process_time() - start)
    #  10: a: 96, g: 98
    #  50: a: 93, g: 94
    # 100: a:91, g:91
    # 1time of 10CV time: epochs=20, mean_bag=100,20220
