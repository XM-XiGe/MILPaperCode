import torch.nn as nn
import torch.nn.functional as func_nn
import warnings
from torch.utils.data import Dataset, DataLoader, Subset
from scipy.io import loadmat
import torch
import torch.optim as optim
from sklearn.metrics import f1_score
import numpy as np
from ANutils import get_index

warnings.filterwarnings('ignore')


class MnistBinaryDateset(Dataset):
    def __init__(self, path):
        self.data = loadmat(path)['data']

    def __getitem__(self, idx):
        return self.data[idx][0], self.data[idx][1].tolist()[0][0]

    def __len__(self):
        return len(self.data)


# Convolve the pictures to instances
class MyConv(nn.Module):
    def __init__(self):
        super(MyConv, self).__init__()
        self.L = 500
        self.D = 128
        self.K = 1

        self.feature_extractor_part1 = nn.Sequential(
            nn.Conv2d(1, 20, kernel_size=5),
            nn.ReLU(),
            nn.MaxPool2d(2, stride=2),
            nn.Conv2d(20, 50, kernel_size=5),
            nn.ReLU(),
            nn.MaxPool2d(2, stride=2)
        )

        self.feature_extractor_part2 = nn.Sequential(
            nn.Linear(50 * 4 * 4, self.L),
            nn.Dropout(),
            nn.ReLU(),
        )

    def forward(self, x):
        x = torch.unsqueeze(x, dim=1)
        H = self.feature_extractor_part1(x)
        H = H.view(-1, 50 * 4 * 4)
        H = self.feature_extractor_part2(H)  # NxL
        return H


class Attention(nn.Module):
    def __init__(self, num_att=500, D=100):
        super(Attention, self).__init__()
        self.num_att = num_att
        self.L = 500
        self.D = D
        self.K = 1
        self.conv = MyConv()
        self.feature_extractor_part = nn.Sequential(
            nn.Linear(self.num_att, self.L),
            nn.ReLU(),
        )

        self.attention = nn.Sequential(
            nn.Linear(self.L, self.D),
            nn.Tanh(),
            nn.Linear(self.D, self.K)
        )

    def forward(self, x):
        x = self.conv(x)

        H = self.feature_extractor_part(x)

        A = self.attention(H)
        A = torch.transpose(A, 1, 0)
        A = func_nn.softmax(A, dim=1)
        M = torch.mm(A, H)
        print(M.shape)
        exit(0)
        return M


class GatedAttention(nn.Module):
    def __init__(self, num_att=500, D=200):
        super(GatedAttention, self).__init__()
        self.num_att = num_att
        self.L = 500
        self.D = D
        self.K = 1
        self.conv = MyConv()
        self.feature_extractor_part = nn.Sequential(
            nn.Linear(self.num_att, self.L),
            nn.ReLU(),
        )

        self.attention_V = nn.Sequential(
            nn.Linear(self.L, self.D),
            nn.Tanh()
        )

        self.attention_U = nn.Sequential(
            nn.Linear(self.L, self.D),
            nn.Sigmoid()
        )

        self.attention_weights = nn.Linear(self.D, self.K)

        self.classifier = nn.Sequential(
            nn.Linear(self.L*self.K, 1),
            nn.Sigmoid()
        )

    def forward(self, x):
        x = self.conv(x)
        H = self.feature_extractor_part(x)  # NxL

        A_V = self.attention_V(H)  # NxD
        A_U = self.attention_U(H)  # NxD
        A = self.attention_weights(A_V * A_U) # element wise multiplication # NxK
        A = torch.transpose(A, 1, 0)  # KxN
        A = func_nn.softmax(A, dim=1)  # softmax over N

        M = torch.mm(A, H)  # KxL

        return M


# 运行测试
def run(trainDataset, testDataset, epochs, lr, i_th_run, i_th_cv, method):
    train_loader = DataLoader(trainDataset, shuffle=False, batch_size=1)
    test_loader = DataLoader(testDataset, shuffle=False, batch_size=1)

    model = None
    if method == 'a':
        model = Attention()
    elif method == 'g':
        model = GatedAttention()

    criterion = torch.nn.CrossEntropyLoss(reduction='sum')
    optimizer = optim.Adam(model.parameters(), lr=lr)

    # 训练一轮，测试一次
    acc_list = []
    f1_list = []
    for epoch in range(epochs):
        # training phase
        model.train()
        running_loss = 0.0
        total = 0.0
        correct = 0.0
        for batch_idx, data in enumerate(train_loader, 0):
            inputs, target = data
            target = target.long()

            inputs = inputs.squeeze(0)
            outputs = model(inputs)
            _, pred = torch.max(outputs.data, dim=1)  # 返回最大值及其索引

            total += target.size(0)
            correct += (pred == target).sum().item()
            acc = correct / total

            loss = criterion(outputs, target)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            running_loss += loss.item()

        print('%2d -th CV, %2d -th Run, %2d -th epoch: Train: loss: %.3f, acc: %.2f:' %
              (i_th_cv + 1, i_th_run + 1, epoch + 1, running_loss / 100, acc * 100), end=' # ')
        # testing phase
        correct = 0
        total = 0
        with torch.no_grad():
            model.eval()
            y_pred = []
            y_true = []
            for data in test_loader:
                inputs, labels = data
                y_true.append(labels)
                inputs = inputs.squeeze(0)
                outputs = model(inputs)

                _, pred = torch.max(outputs.data, dim=1)  # 返回最大值及其索引
                y_pred.append(pred)
                total += labels.size(0)
                correct += (pred == labels).sum().item()
                acc = correct / total
        f1 = f1_score(y_true, y_pred, zero_division=0)
        print('Test: acc: %.2f | f1: %.2f' % (acc, f1))
        acc_list.append(acc)
        f1_list.append(f1)
        if acc == 1:
            break
    return np.max(acc_list), np.max(f1_list)


# one cv
def one_cv(path, epochs, lr, i_th_cv, method, para_k):
    AllDataSet = MnistBinaryDateset(path=path)
    train_idx_list, test_idx_list = get_index(len(AllDataSet), para_k=10)
    acc_list, f1_list = [], []
    for i in range(para_k):
        trainDataset = Subset(AllDataSet, train_idx_list[i])
        testDataset = Subset(AllDataSet, test_idx_list[i])
        f1, acc = run(trainDataset=trainDataset, testDataset=testDataset,
                      epochs=epochs, lr=lr, i_th_run=i, i_th_cv=i_th_cv, method=method)
        acc_list.append(acc)
        f1_list.append(f1)
    return np.mean(acc_list), np.mean(f1_list)


# n cv
def n_cv(path, epochs, lr, cv_num, method, para_k):
    acc_list, f1_list = [], []
    for i in range(cv_num):
        acc, f1 = one_cv(path=path, epochs=epochs, lr=lr, i_th_cv=i, method=method, para_k=para_k)
        acc_list.append(acc)
        f1_list.append(f1)
    return np.mean(acc_list), np.std(acc_list), np.mean(f1_list), np.std(f1_list)


if __name__ == '__main__':
    path = '../../Data/Mnist-bags/Binary/mnist_1.mat'
    dataset_name = path.split('/')[-1]
    para_k = 10
    epochs = 10
    lr = 0.001
    method = 'a'

    acc, acc_std, f1, f1_std = n_cv(path=path, epochs=epochs, lr=lr, method=method, cv_num=5, para_k=para_k)
    print('-' * 20)
    print(dataset_name)
    print('epochs: ', epochs, end=', ')
    print('lr:', lr, end=',')
    print('method: ', method, end=', ')
    print('para_k: ', para_k)
    print('Mean Result of 5 CV : acc: $%.2f_{\\pm%.2f}$ | f1: $%.2f_{\\pm%.2f}$'
          % (acc * 100, acc_std * 100, f1 * 100, f1_std * 100))

    # mnist_0: method:'a', epochs:10, lr:0.001, para_k=10, acc: $96.1_{\pm0.4}$ | f1: $96.3_{\pm0.2}$
    # mnist_1: method:'a', epochs:10, lr:0.001, para_k=10, acc: $94.3_{\pm1.1}$ | f1: $94.5_{\pm1.2}$
    # mnist_2: method:'a', epochs:10, lr:0.001, para_k=10, acc: $94.1_{\pm0.0}$ | f1: $94.9_{\pm1.1}$
    # mnist_3: method:'a', epochs:10, lr:0.001, para_k=10, acc: $86.1_{\pm9.1}$ | f1: $86.1_{\pm2.7}$
    # mnist_4: method:'a', epochs:10, lr:0.001, para_k=10, acc: $95.1_{\pm1.2}$ | f1: $95.0_{\pm1.0}$
    # mnist_5: method:'a', epochs:10, lr:0.001, para_k=10, acc: $95.9_{\pm0.7}$ | f1: $95.9_{\pm0.9}$
    # mnist_6: method:'a', epochs:10, lr:0.001, para_k=10, acc: $98.1_{\pm0.2}$ | f1: $98.1_{\pm0.3}$
    # mnist_7: method:'a', epochs:10, lr:0.001, para_k=10, acc: $97.1_{\pm0.6}$ | f1: $97.1_{\pm0.6}$
    # mnist_8: method:'a', epochs:10, lr:0.001, para_k=10, acc: $87.0_{\pm9.2}$ | f1: $87.5_{\pm8.5}$
    # mnist_8: method:'a', epochs:10, lr:0.001, para_k=10, acc: $94.2_{\pm1.7}$ | f1: $94.3_{\pm1.4}$

    # mnist_0: method:'g', epochs:10, lr:0.001, para_k=10, acc: $97.4_{\pm0.5}$ | f1: $97.7_{\pm0.2}$
    # mnist_1: method:'g', epochs:10, lr:0.001, para_k=10, acc: $95.3_{\pm1.6}$ | f1: $95.5_{\pm1.4}$
    # mnist_2: method:'g', epochs:10, lr:0.001, para_k=10, acc: $95.1_{\pm1.2}$ | f1: $95.1_{\pm1.1}$
    # mnist_3: method:'g', epochs:10, lr:0.001, para_k=10, acc: $87.8_{\pm9.1}$ | f1: $87.5_{\pm8.7}$
    # mnist_4: method:'g', epochs:10, lr:0.001, para_k=10, acc: $96.7_{\pm1.0}$ | f1: $96.9_{\pm1.0}$
    # mnist_5: method:'g', epochs:10, lr:0.001, para_k=10, acc: $97.0_{\pm0.8}$ | f1: $97.2_{\pm0.9}$
    # mnist_6: method:'g', epochs:10, lr:0.001, para_k=10, acc: $99.3_{\pm0.2}$ | f1: $99.3_{\pm0.2}$
    # mnist_7: method:'g', epochs:10, lr:0.001, para_k=10, acc: $98.6_{\pm0.7}$ | f1: $98.6_{\pm0.6}$
    # mnist_8: method:'g', epochs:10, lr:0.001, para_k=10, acc: $88.2_{\pm6.2}$ | f1: $88.5_{\pm8.5}$
    # mnist_8: method:'g', epochs:10, lr:0.001, para_k=10, acc: $95.1_{\pm1.7}$ | f1: $95.1_{\pm1.4}$


