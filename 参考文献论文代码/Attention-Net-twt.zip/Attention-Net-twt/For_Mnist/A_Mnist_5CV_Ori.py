import torch
import torch.nn as nn
import torch.nn.functional as func_nn
import warnings
from torch.utils.data import Dataset, DataLoader, Subset
from scipy.io import loadmat
import torch
import torch.nn.functional as F
import torch.optim as optim
from sklearn.metrics import f1_score, accuracy_score
import numpy as np
from utils import get_index
import time

warnings.filterwarnings('ignore')


class MnistBinaryDateset(Dataset):
    def __init__(self, path):
        self.data = loadmat(path)['data']

    def __getitem__(self, idx):
        return self.data[idx][0], self.data[idx][1].tolist()[0][0]

    def __len__(self):
        return len(self.data)


# Convolve the pictures to instances
class MyConv(nn.Module):
    def __init__(self):
        super(MyConv, self).__init__()
        self.L = 500
        self.D = 128
        self.K = 1

        self.feature_extractor_part1 = nn.Sequential(
            nn.Conv2d(1, 20, kernel_size=5),
            nn.ReLU(),
            nn.MaxPool2d(2, stride=2),
            nn.Conv2d(20, 50, kernel_size=5),
            nn.ReLU(),
            nn.MaxPool2d(2, stride=2)
        )

        self.feature_extractor_part2 = nn.Sequential(
            nn.Linear(50 * 4 * 4, self.L),
            nn.Dropout(),
            nn.ReLU(),
        )

    def forward(self, x):
        x = torch.transpose(x, 0, 1)
        H = self.feature_extractor_part1(x)
        H = H.view(-1, 50 * 4 * 4)
        H = self.feature_extractor_part2(H)  # NxL
        return H


class Attention(nn.Module):
    def __init__(self, num_att=500, D=200):
        super(Attention, self).__init__()
        self.num_att = num_att
        self.L = 500
        self.D = D
        self.K = 1
        self.conv = MyConv()
        self.feature_extractor_part = nn.Sequential(
            nn.Linear(self.num_att, self.L),
            nn.ReLU(),
        )

        self.attention = nn.Sequential(
            nn.Linear(self.L, self.D),
            nn.Tanh(),
            nn.Linear(self.D, self.K)
        )

        self.classifier = nn.Sequential(
            nn.Linear(self.L*self.K, 1),
            nn.Sigmoid()
        )

    def forward(self, x):
        x = self.conv(x)

        H = self.feature_extractor_part(x)

        A = self.attention(H)
        A = torch.transpose(A, 1, 0)
        A = func_nn.softmax(A, dim=1)
        M = torch.mm(A, H)

        Y_prob = self.classifier(M)
        Y_hat = torch.ge(Y_prob, 0.5).float()

        return Y_prob, Y_hat, A

    # AUXILIARY METHODS
    def calculate_classification_error(self, X, Y):
        Y = Y.float()
        _, Y_hat, _ = self.forward(X)
        pred = 1 if Y_hat.eq(Y).cpu().item() else 0
        error = 1. - pred

        return error, Y_hat

    def calculate_objective(self, X, Y):
        Y = Y.float()
        Y_prob, _, A = self.forward(X)
        Y_prob = torch.clamp(Y_prob, min=1e-5, max=1. - 1e-5)
        neg_log_likelihood = -1. * (Y * torch.log(Y_prob) + (1. - Y) * torch.log(1. - Y_prob))  # negative log bernoulli

        return neg_log_likelihood, A


class GatedAttention(nn.Module):
    def __init__(self, num_att=500, D=200):
        super(GatedAttention, self).__init__()
        self.num_att = num_att
        self.L = 500
        self.D = D
        self.K = 1
        self.conv = MyConv()
        self.feature_extractor_part = nn.Sequential(
            nn.Linear(self.num_att, self.L),
            nn.ReLU(),
        )

        self.attention_V = nn.Sequential(
            nn.Linear(self.L, self.D),
            nn.Tanh()
        )

        self.attention_U = nn.Sequential(
            nn.Linear(self.L, self.D),
            nn.Sigmoid()
        )

        self.attention_weights = nn.Linear(self.D, self.K)

        self.classifier = nn.Sequential(
            nn.Linear(self.L*self.K, 1),
            nn.Sigmoid()
        )

    def forward(self, x):
        x = self.conv(x)
        H = self.feature_extractor_part(x)  # NxL

        A_V = self.attention_V(H)  # NxD
        A_U = self.attention_U(H)  # NxD
        A = self.attention_weights(A_V * A_U) # element wise multiplication # NxK
        A = torch.transpose(A, 1, 0)  # KxN
        A = func_nn.softmax(A, dim=1)  # softmax over N

        M = torch.mm(A, H)  # KxL

        Y_prob = self.classifier(M)
        Y_hat = torch.ge(Y_prob, 0.5).float()

        return Y_prob, Y_hat, A

    # AUXILIARY METHODS
    def calculate_classification_error(self, X, Y):
        Y = Y.float()
        _, Y_hat, _ = self.forward(X)
        error = 1. - Y_hat.eq(Y).cpu().float().mean().item()

        return error, Y_hat

    def calculate_objective(self, X, Y):
        Y = Y.float()
        Y_prob, _, A = self.forward(X)
        Y_prob = torch.clamp(Y_prob, min=1e-5, max=1. - 1e-5)
        neg_log_likelihood = -1. * (Y * torch.log(Y_prob) + (1. - Y) * torch.log(1. - Y_prob))  # negative log bernoulli

        return neg_log_likelihood, A


# 运行测试
def run(trainDataset, testDataset, epochs, lr, i_th_run, i_th_cv, method):
    train_loader = DataLoader(trainDataset, shuffle=False, batch_size=1)
    test_loader = DataLoader(testDataset, shuffle=False, batch_size=1)

    model = None
    if method == 'a':
        model = Attention()
    elif method == 'g':
        model = GatedAttention()

    criterion = torch.nn.CrossEntropyLoss(reduction='sum')
    optimizer = optim.Adam(model.parameters(), lr=lr)

    # 训练一轮，测试一次
    acc_list = []
    f1_list = []
    batch_count = 0
    for epoch in range(epochs):
        # print(epoch)
        # training phase
        model.train()
        tr_loss, tr_error = 0, 0
        for batch_idx, data in enumerate(train_loader, 0):
            data, label = data
            loss, _ = model.calculate_objective(data.float(), label)
            optimizer.zero_grad()
            tr_loss += loss.detach().numpy()
            error, _ = model.calculate_classification_error(data.float(), label)
            loss.backward()
            optimizer.step()
            tr_error += error
            batch_count += 1
        # print('Train Loss: %3f', tr_loss / batch_count)

        pred_list = []
        label_list = []
        for batch_idx, data in enumerate(test_loader, 0):
            data, label = data
            _, pre_lab = model.calculate_classification_error(data.float(), label)
            pred_list.append(pre_lab[0].numpy())
            label_list.append(label.numpy())
        acc, f1 = accuracy_score(pred_list, label_list), f1_score(pred_list, label_list)
        acc_list.append(acc)
        f1_list.append(f1)
    return np.max(acc_list), np.max(f1_list)

# one cv
def one_cv(path, epochs, lr, i_th_cv, method, para_k):
    AllDataSet = MnistBinaryDateset(path=path)
    train_idx_list, test_idx_list = get_index(len(AllDataSet), para_k=para_k)
    acc_list, f1_list = [], []
    for i in range(para_k):
        trainDataset = Subset(AllDataSet, train_idx_list[i])
        testDataset = Subset(AllDataSet, test_idx_list[i])
        f1, acc = run(trainDataset=trainDataset, testDataset=testDataset,
                      epochs=epochs, lr=lr, i_th_run=i, i_th_cv=i_th_cv, method=method)
        acc_list.append(acc)
        f1_list.append(f1)
    return np.mean(acc_list), np.mean(f1_list)


# n cv
def n_cv(path, epochs, lr, cv_num, method, para_k):
    acc_list, f1_list = [], []
    for i in range(cv_num):
        acc, f1 = one_cv(path=path, epochs=epochs, lr=lr, i_th_cv=i, method=method, para_k=para_k)
        acc_list.append(acc)
        f1_list.append(f1)
    return np.mean(acc_list), np.std(acc_list), np.mean(f1_list), np.std(f1_list)


if __name__ == '__main__':
    start = time.process_time()
    path = '../../Data/Mnist-bags/Binary/mnist_0.mat'
    dataset_name = path.split('/')[-1]
    para_k = 10
    epochs = 20
    lr = 0.001
    method = 'a'

    acc, acc_std, f1, f1_std = n_cv(path=path, epochs=epochs, lr=lr, method=method, cv_num=1, para_k=para_k)
    print('-' * 20)
    print(dataset_name)
    print('epochs: ', epochs, end=', ')
    print('lr:', lr, end=',')
    print('method: ', method, end=', ')
    print('para_k: ', para_k)
    print('Mean Result of 5 CV : acc: $%.2f_{\\pm%.2f}$ | f1: $%.2f_{\\pm%.2f}$'
          % (acc * 100, acc_std * 100, f1 * 100, f1_std * 100))
    print('Time cost:', time.process_time() - start)
    # time: epochs=20, 2532