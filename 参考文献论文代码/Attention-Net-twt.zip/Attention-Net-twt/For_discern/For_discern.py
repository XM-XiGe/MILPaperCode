from torch.utils.data import Dataset, DataLoader, Subset
import torch.nn as nn
import torch
import torch.nn.functional as F
import torch.optim as optim
from sklearn.metrics import f1_score
import numpy as np
import time
from tqdm import tqdm
from sklearn.metrics import euclidean_distances as eucl
from MILFrame.MIL import MIL


def get_index(num_bags=92, para_k=10, seed=None):
    if seed is not None:
        np.random.seed(seed)
    temp_rand_idx = np.random.permutation(num_bags)

    temp_fold = int(np.ceil(num_bags / para_k))
    ret_tr_idx = {}
    ret_te_idx = {}
    for i in range(para_k):
        temp_tr_idx = temp_rand_idx[0: i * temp_fold].tolist()
        temp_tr_idx.extend(temp_rand_idx[(i + 1) * temp_fold:])
        ret_tr_idx[i] = temp_tr_idx
        ret_te_idx[i] = temp_rand_idx[i * temp_fold: (i + 1) * temp_fold].tolist()
    return ret_tr_idx, ret_te_idx


# 加载包含包标签和实例标签的数据集
def load_data(path='../Data/Benchmark/musk1+.mat'):
    mil = MIL(para_path=path)
    labels = mil.bags_label
    bag_labels = np.where(labels < 0, 0, labels)
    bags = []
    ins_labels = []
    for i in range(mil.num_bags):
        bags.append(mil.bags[i, 0][:, :-1])
        ins_labels.append(mil.bags[i, 0][:, -1])
    return bags, bag_labels


def compute_discer(vectors, labels):
    positive_vectors, negative_vectors = [], []
    for i in range(len(vectors)):
        if labels[i] == 1:
            positive_vectors.append(vectors[i])
        elif labels[i] == 0:
            negative_vectors.append(vectors[i])
    positive_vectors = np.array(positive_vectors)
    negative_vectors = np.array(negative_vectors)
    # 均值向量
    positive_mean = np.mean(positive_vectors, axis=0)
    negative_mean = np.mean(negative_vectors, axis=0)
    # 平均距离
    positive_dis = np.mean(eucl(positive_vectors), axis=None)
    negative_dis = np.mean(eucl(negative_vectors), axis=None)
    fenmu = positive_dis + negative_dis
    return eucl([positive_mean], [negative_mean])[0][0] / fenmu  # if fenmu > 1e-3 else 1e-3


class Attention(nn.Module):
    def __init__(self, num_att, D):
        super(Attention, self).__init__()
        self.num_att = num_att
        self.L = 500
        self.D = D
        self.K = 1

        self.feature_extractor_part = nn.Sequential(
            nn.Linear(self.num_att, self.L),
            nn.ReLU(),
        )

        self.attention = nn.Sequential(
            nn.Linear(self.L, self.D),
            nn.Tanh(),
            nn.Linear(self.D, self.K)
        )

        self.classifier = nn.Sequential(
            nn.Linear(self.L * self.K, 2),
            nn.Sigmoid()
        )

    def forward(self, x):
        x = x.float()
        if x.shape[0] < 2:
            x = self.feature_extractor_part(x)
            Y_prob = self.classifier(x)
            return Y_prob, x
        H = self.feature_extractor_part(x)

        A = self.attention(H)
        A = torch.transpose(A, 1, 0)
        A = F.softmax(A, dim=1)
        M = torch.mm(A, H)

        Y_prob = self.classifier(M)
        # print(Y_prob)
        # exit(0)
        return Y_prob, M


# 返回包与其标签的DataSet类
class MyDataSet(Dataset):
    def __init__(self, path='../MILFrame/data/benchmark/musk1+.mat'):
        self.bags, self.labels = load_data(path=path)

    def __getitem__(self, idx):
        return self.bags[idx], self.labels[idx]

    def __len__(self):
        return len(self.labels)


def run_test(trainDataSet, testDataSet, epochs, lr, n_class):
    train_loader = DataLoader(trainDataSet, shuffle=False, batch_size=1)
    test_loader = DataLoader(testDataSet, shuffle=False, batch_size=1)
    ins_len = len(trainDataSet[0][0][0])
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    model = Attention(ins_len, 50).to(device)
    criterion = torch.nn.CrossEntropyLoss(reduction='sum')  # 与tensorflow不同，此处交叉熵损失先会将输入softmax
    # 并且真实标签只能为单数字，不能为one-hot
    optimizer = optim.Adam(model.parameters(), lr=lr)
    # 训练一轮，测试一次
    acc_list = []
    f1_list = []
    m_discer_list = []
    for epoch in range(epochs):
        # training phase
        model.train()
        running_loss = 0.0
        for batch_idx, data in enumerate(train_loader, 0):
            inputs, target = data
            target = target.long()
            target = target.to(device)
            inputs = inputs.squeeze(0)
            inputs = inputs.to(device)
            outputs, m = model(inputs)

            loss = criterion(outputs, target)

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            running_loss += loss.item()
        # print('loss of %3d -th opoch: %.3f :'
        #       % (epoch + 1, running_loss / len(trainDataSet)), end=' # ')
        correct = 0
        total = 0
        with torch.no_grad():
            model.eval()
            y_pred = []
            y_true = []
            m_list = []
            for data in test_loader:
                inputs, labels = data
                y_true.append(labels.cpu().item())
                inputs = inputs.squeeze(0)
                inputs = inputs.to(device)
                outputs, m = model(inputs)
                m_list.append(np.squeeze(m.cpu().numpy()))

                _, pred = torch.max(outputs.data, dim=1)  # 返回最大值及其索引
                y_pred.append(pred.cpu().numpy())
                total += labels.size(0)
                correct += (pred == labels.cpu().item()).sum().detach().cpu().item()
                acc = correct / total
        m_list = np.array(m_list)
        m_discer = 0
        if np.sum(y_true) != 0 and np.sum(y_true) != len(y_true) and len(y_true) > 2:
            m_discer = compute_discer(m_list, y_true)
        m_discer_list.append(m_discer)
        f1 = f1_score(y_true, y_pred, zero_division=0)
        # print('Test: acc: %.2f | f1: %.2f, Dsicer: m: %.3f' % (acc, f1, m_discer))
        acc_list.append(acc)
        f1_list.append(f1)
        if acc == 1:
            break
    return np.max(acc_list), np.max(f1_list), np.max(m_discer_list)


def one_cv(path, para_k, epochs, lr):
    AllDataSet = MyDataSet(path)
    n_class = np.max(AllDataSet[:][1]) + 1
    train_idx_list, test_idx_list = get_index(len(AllDataSet), para_k=para_k)
    acc_list, f1_list, m_list = [], [], []
    for i in tqdm(range(para_k)):
        trainDataSet = Subset(AllDataSet, train_idx_list[i])
        testDataSet = Subset(AllDataSet, test_idx_list[i])
        acc, f1, m = run_test(trainDataSet=trainDataSet, testDataSet=testDataSet,
                              epochs=epochs, lr=lr, n_class=n_class)
        acc_list.append(acc)
        f1_list.append(f1)
        m_list.append(m)
    print('-' * 50 + 'One CV Done' + '|' + 'acc: ' + str(np.mean(acc_list)) + ' f1: ' + str(np.mean(f1_list)))
    return float(np.mean(acc_list)), float(np.mean(f1_list)), float(np.mean(m_list))


def n_cv(path, num_cv, para_k, epochs, lr):
    acc_list, f1_list, m_list = [], [], []
    for i in range(num_cv):
        acc, f1, m = one_cv(path=path, para_k=para_k, epochs=epochs, lr=lr)
        acc_list.append(acc)
        f1_list.append(f1)
        m_list.append(m)
    return float(np.mean(acc_list)), float(np.std(acc_list)), float(np.mean(f1_list)), float(np.std(f1_list)), \
           float(np.mean(m_list)), float(np.std(m_list))


if __name__ == '__main__':
    start = time.process_time()
    path = '../../Data/Text(sparse)/normalized/alt_atheism+.mat'
    num_cv = 5
    para_k = 10
    epochs = 80
    lr = 0.001
    acc, acc_std, f1, f1_std, m, m_std = n_cv(path, num_cv, para_k, epochs, lr)

    print('*' * 10 + path.split('/')[-1].split('.')[0] + '*' * 10)
    print('lr: ', lr)
    print('epochs: ', epochs)
    print('Mean Result of 5 CV : acc: $%.2f_{\\pm%.2f}$ | f1: $%.2f_{\\pm%.2f}$'
          % (acc * 100, acc_std * 100, f1 * 100, f1_std * 100))
    print('Discernibility: m: $%.2f_{\\pm%.2f}$'
          % (m, m_std))
    print('Time Cost: ', (time.process_time() - start))