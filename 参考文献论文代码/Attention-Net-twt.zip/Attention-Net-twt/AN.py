import torch
from torch.utils.data import DataLoader, Subset
from ANData import MyDataSetBag
from Models import Attention
from ANutils import get_index
import torch.optim as optim
import numpy as np


"""根据师兄的Attnetion-Net修改得到"""
AllDataSet = MyDataSetBag(path='../Data/Benchmark/musk1+.mat')
train_idx_list, test_idx_list = get_index(len(AllDataSet), para_k=10, seed=66)

trainDataSet = Subset(AllDataSet, train_idx_list[0])
testDataSet = Subset(AllDataSet, test_idx_list[0])

ins_len = len(trainDataSet[0][0][0])


train_loader = DataLoader(trainDataSet, shuffle=False, batch_size=1)
test_loader = DataLoader(testDataSet, shuffle=False, batch_size=1)


# 定义损失函数
class MILoss(torch.nn.Module):
    def __init__(self):
        super(MILoss, self).__init__()

    def forward(self, pred, true):
        prob = pred.squeeze()
        label = true.squeeze()
        loss = None
        if label.numpy() == 0:
            loss = prob - label
        elif label.numpy() == 1:
            loss = label - prob

        return loss


model = Attention(num_att=ins_len, D=len(AllDataSet))

criterion = MILoss()
optimizer = optim.Adam(model.parameters(), lr=0.001)


def train(epoch):
    running_loss = 0.0
    for batch_idx, data in enumerate(train_loader, 0):
        inputs, target = data
        target = target.long()
        bag = inputs

        optimizer.zero_grad()

        outputs = model(bag)

        # print(outputs)
        # print(target)
        # exit(0)  # 可能是数据维度不匹配问题

        loss = criterion(outputs, target)
        loss.backward()
        optimizer.step()

        running_loss += loss.item()

    print('%d -th opoch loss: %.3f' % (epoch + 1, running_loss / len(trainDataSet)), end=' ### ')


def test():
    correct = 0
    total = 0
    with torch.no_grad():
        for data in test_loader:
            inputs, label = data
            bag = inputs
            outputs = model(bag)

            ins_labels = outputs.squeeze()
            bag_label = 0  # 预测标签
            if torch.sum(torch.where(ins_labels > 0.5, ins_labels, torch.tensor(0.0, dtype=torch.float))) > 0:
                bag_label = 1
            # print(bag_label)
            label = label.item()
            total += 1
            if label == bag_label:
                correct += 1
            acc = 100 * correct / total
    print('Accuracy on test set: %d %% [%d / %d]' % (acc, correct, total))
    return acc


if __name__ == '__main__':
    acc_list = []
    for epoch in range(500):
        train(epoch)
        acc_list.append(test())
    print('Best Accuracy on Test Set : {}'.format(np.max(acc_list)))