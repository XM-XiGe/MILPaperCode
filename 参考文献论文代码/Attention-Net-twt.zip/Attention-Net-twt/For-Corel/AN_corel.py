import torch
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
import torch.optim as optim
from sklearn.metrics import roc_auc_score, f1_score, accuracy_score
import numpy as np
import time
import os
import torch.nn as nn
from ANutils import load_multi_class_bag
from tqdm import tqdm


class MyDataset(Dataset):
    def __init__(self, bags, labels):
        self.bags = bags
        self.labels = labels

    def __getitem__(self, idx):
        return self.bags[idx], self.labels[idx]

    def __len__(self):
        return len(self.labels)


# 每个类别随机选取一半作为训练集,另一半作为测试集,直接返回pytorch的Dataset类
def load_data(path, train_tate):
    bags, labels = load_multi_class_bag(path)
    n_bags = labels.shape[0]
    n_class = np.max(labels) + 1
    # 一共n_class行，每一行的包标签为对应行索引
    bag_idx = np.reshape(np.arange(0, n_bags), (-1, 100))
    train_bag_idx, test_bag_idx = [], []
    for i in range(n_class):
        total_index = bag_idx[i]  # 包标签为i的所有包索引
        train_idx = np.random.choice(total_index, int(len(total_index) * train_tate), replace=False)
        test_idx = np.setdiff1d(total_index, train_idx)
        train_bag_idx.append(np.sort(train_idx))
        test_bag_idx.append(np.sort(test_idx))
    train_bag_idx = np.reshape(train_bag_idx, (-1))
    test_bag_idx = np.reshape(test_bag_idx, (-1))
    np.random.shuffle(train_bag_idx)
    np.random.shuffle(test_bag_idx)
    trainDataset = MyDataset(bags[train_bag_idx], labels[train_bag_idx])
    testDataset = MyDataset(bags[test_bag_idx], labels[test_bag_idx])
    return trainDataset, testDataset


# attention net 模型
class Attention(nn.Module):
    def __init__(self, num_att, D, n_class):
        super(Attention, self).__init__()
        self.num_att = num_att
        self.n_class = n_class
        self.L = 5 * num_att
        self.D = D
        self.K = 1
        self.feature_extractor_part = nn.Sequential(
            nn.Linear(self.num_att, self.L),
            nn.ReLU(),
        )

        self.attention = nn.Sequential(
            nn.Linear(self.L, self.D),
            nn.Tanh(),
            nn.Linear(self.D, self.K)
        )
        self.classifier = nn.Sequential(
            nn.Linear(self.L * self.K, self.n_class),
            nn.Sigmoid()
        )

    def forward(self, x):
        x = x.float()
        H = self.feature_extractor_part(x)

        A = self.attention(H)  # A为注意力系数
        A = torch.transpose(A, 1, 0)
        A = F.softmax(A, dim=1)
        M = torch.mm(A, H)
        return self.classifier(M)


class GatedAttention(nn.Module):
    def __init__(self, num_att, D, n_class):
        super(GatedAttention, self).__init__()
        self.num_att = num_att
        self.n_class = n_class
        self.L = 2 * num_att
        self.D = D
        self.K = 1
        self.feature_extractor_part = nn.Sequential(
            nn.Linear(self.num_att, self.L),
            nn.ReLU(),
        )

        self.attention_V = nn.Sequential(
            nn.Linear(self.L, self.D),
            nn.Tanh()
        )

        self.attention_U = nn.Sequential(
            nn.Linear(self.L, self.D),
            nn.Sigmoid()
        )

        self.attention_weights = nn.Linear(self.D, self.K)

        self.classifier = nn.Sequential(
            nn.Linear(self.L*self.K, self.n_class),
            nn.Sigmoid()
        )

    def forward(self, x):
        x = x.float()
        H = self.feature_extractor_part(x)  # NxL

        A_V = self.attention_V(H)  # NxD
        A_U = self.attention_U(H)  # NxD
        A = self.attention_weights(A_V * A_U)  # element wise multiplication # NxK
        A = torch.transpose(A, 1, 0)  # KxN
        A = F.softmax(A, dim=1)  # softmax over N

        M = torch.mm(A, H)  # KxL

        return self.classifier(M)


# 运行测试
def run(path, n_class, train_rate, epochs, lr, method):
    trainDataset, testDataset = load_data(path, train_rate)
    ins_len = len(trainDataset[0][0][0])

    train_loader = DataLoader(trainDataset, shuffle=False, batch_size=1)
    test_loader = DataLoader(testDataset, shuffle=False, batch_size=1)
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    # device = torch.device("cpu")
    model = None
    if method == 'a':
        model = Attention(ins_len, 100, n_class).to(device)
    elif method == 'g':
        model = GatedAttention(ins_len, 100, n_class).to(device)

    criterion = torch.nn.CrossEntropyLoss(reduction='sum')
    optimizer = optim.Adam(model.parameters(), lr=lr)

    # 训练一轮，测试一次
    acc_list = []
    f1_list = []
    auc_list = []
    for epoch in range(epochs):
        # training phase
        model.train()
        running_loss = 0.0
        total = 0.0
        correct = 0.0
        for batch_idx, data in enumerate(train_loader, 0):
            inputs, target = data
            target = target.long()
            target = target.to(device)
            inputs = inputs.squeeze(0)
            inputs = inputs.to(device)
            outputs = model(inputs)
            _, pred = torch.max(outputs.data, dim=1)  # 返回最大值及其索引

            total += target.size(0)
            correct += (pred == target).sum().item()
            acc = correct / total

            loss = criterion(outputs, target)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            running_loss += loss.item()

        # print('%2d -th epoch: Train: loss: %.3f, acc: %.2f:' %
        #       (epoch + 1, running_loss / 100, acc * 100), end=' # ')
        # testing phase
        correct = 0
        total = 0
        with torch.no_grad():
            model.eval()
            y_pred = []
            y_true = []
            y_prob = []
            for data in test_loader:
                inputs, labels = data
                labels = labels.to(device)
                inputs = inputs.to(device)
                y_true.append(labels.detach().cpu().item())
                inputs = inputs.squeeze(0)
                outputs = model(inputs)
                temp_prob = torch.softmax(outputs, 1)
                y_prob.append(temp_prob.detach().cpu().numpy())
                _, pred = torch.max(outputs.data, dim=1)  # 返回最大值及其索引
                y_pred.append(pred.detach().cpu().item())
                total += labels.size(0)
                correct += (pred == labels).sum().detach().cpu().item()
                acc = correct / total
        f1 = f1_score(y_true, y_pred, zero_division=0, average='macro')
        y_prob = np.squeeze(np.array(y_prob))
        auc = roc_auc_score(y_true, y_prob, multi_class='ovr')
        auc_list.append(auc)
        # print('Test: acc: %.2f | f1: %.2f' % (acc, f1))
        acc_list.append(acc)
        f1_list.append(f1)
        if acc == 1:
            break
    return np.max(acc_list), np.max(f1_list), np.max(auc_list)


if __name__ == '__main__':
    # path = '../../Data/Ele_v_Fox_v_Tiger/Ele_fox_tiger.mat'
    # dataset_name = path.split('/')[-1]
    # n_class = int(dataset_name.split('-')[1])
    # # n_class = 3
    # train_rate = 0.9
    # epochs = 100
    # lr = 0.001
    # method = 'a'
    # times = 2
    # acc_list, f1_list, auc_list = [], [], []
    # for i in tqdm(range(times)):
    #     acc, f1, auc = run(path, n_class, train_rate, epochs, lr, method)
    #     acc_list.append(acc)
    #     f1_list.append(f1)
    #     auc_list.append(auc)
    # acc_avg = float(np.mean(acc_list))
    # acc_std = float(np.std(acc_list, ddof=1))
    # f1_avg = float(np.mean(f1_list))
    # f1_std = float(np.std(f1_list, ddof=1))
    # auc_avg = float(np.mean(auc_list))
    # auc_std = float(np.std(auc_list, ddof=1))
    # print('train_rate:', train_rate)
    # print('Acc: $%.3f_{\\pm%.3f}$, F1: $%.3f_{\\pm%.3f}$, AUC: $%.3f_{\\pm%.3f}$'
    #       % (acc_avg, acc_std, f1_avg, f1_std, auc_avg, auc_std))
    start = time.process_time()
    path = '../../Data/Corel/Blobworld/类别有重复/corel-10/corel-10-b-230+.mat'
    dataset_name = path.split('/')[-1]
    n_class = int(dataset_name.split('-')[1])
    # n_class = 3
    train_rate = 0.9
    epochs = 100
    lr = 0.001
    method = 'a'
    acc, f1, auc = run(path, n_class, train_rate, epochs, lr, method)
    print('Time cost:', time.process_time() - start)
    """
    一次10CV: epochs=100, tr_rate=0.9:
    corel-3: 623, 14895
    corel_5: 992, 23718
    corel-10: 1953, 46695
    """
    # n_class = 3, test_rate = 0.5, Acc: $81.53_{\pm5.37}$, F1: $81.02_{\pm6.09}$, AUC: $0.911_{\pm0.016}$
    # n_class = 3, test_rate = 0.3, Acc: $84.56_{\pm5.35}$, F1: $84.29_{\pm6.01}$, AUC: $0.930_{\pm0.015}$
    # n_class = 3, test_rate = 0.1, Acc: $89.33_{\pm7.83}$, F1: $88.97_{\pm8.14}$, AUC: $0.973_{\pm0.039}$

    # n_class = 5, test_rate = 0.5, Acc: $49.53_{\pm7.30}$, F1: $41.91_{\pm0.47}$, AUC: $0.896_{\pm0.047}$
    # n_class = 5, test_rate = 0.3, Acc: $57.72_{\pm6.67}$, F1: $52.51_{\pm1.77}$, AUC: $0.930_{\pm0.002}$
    # n_class = 5, test_rate = 0.1, Acc: $65.60_{\pm1.97}$, F1: $60.96_{\pm5.94}$, AUC: $0.956_{\pm0.022}$

    # n_class =10, test_rate = 0.5, Acc: $12.57_{\pm7.88}$, F1: $04.92_{\pm9.20}$, AUC: $0.612_{\pm0.055}$
    # n_class =10, test_rate = 0.3, Acc: $17.04_{\pm1.65}$, F1: $09.97_{\pm3.78}$, AUC: $0.671_{\pm0.179}$
    # n_class =10, test_rate = 0.1, Acc: $24.80_{\pm9.61}$, F1: $19.02_{\pm2.50}$, AUC: $0.690_{\pm0.044}$

