import SMMD_use_saved_dis as SMMD
import numpy as np
acc_list = []
std_list = []
dataset = ''
k = 200
for i in range(k):
    print('第 %s 轮开始' % i)
    smmd = SMMD.SMMD(dis_file_path=r'../distance/SMMD/Newsgroups/sci_crypt.mat/max/0.2_max_sci_crypt.mat',
                     u_for_total_DP=0.8,
                     file_path=r'../MILframe/data/Newsgroups/unnormalized/sci_crypt.mat')
    dataset = smmd.dataset
    acc_list.append(smmd.accuracy)
    std_list.append(smmd.std)
# print(acc_list)
# print(std_list)
best_acc = np.max(acc_list)
best_std = std_list[acc_list.index(best_acc)]
# print('%s 轮的最高准确率为 %s：' % (k, best_acc))
# print('对应标准差为：', best_std)
print(dataset)
print(r'$%.1f_{\pm %.1f}$' % (best_acc * 100, best_std * 100))
