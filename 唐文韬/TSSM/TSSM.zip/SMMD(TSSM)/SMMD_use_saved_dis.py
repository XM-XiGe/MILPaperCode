from MILframe import MIL
from DP_TWT import DP
import numpy as np
import time
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
import os


class SMMD:
    """
    使用不同包内聚类比例的距离，每个结果文件格式为 : 数据集名 包内聚类比例 包间聚类比例 准确率 std
    """

    def __init__(self, kernel='gaussian', classfier='knn',
                 dis_file_path=r'..\distance\SMMD\Newsgroups\alt_atheism.mat',
                 file_path=r'..\MILframe\data\Newsgroups\unnormalized\alt_atheism.mat',
                 u_for_total_DP=0.4):
        self.dataset = file_path.split('/')[-1]
        self.mil = MIL.MIL(file_path)
        self.bags_dis_matrix = self.get_bags_dis_matrix(dis_file=dis_file_path)
        # print(self.bags_dis_matrix)
        self.key_bags_list = self.get_key_bags_list(u_for_total_DP, kernel=kernel)
        self.key_bags_list.sort()
        # print(self.key_bags_list)
        self.trsed_vector_matrix = self.get_trsed_vector_matrix()  # 最后一列为标签
        # print(self.trsed_vector_matrix)
        self.accuracy, self.accuracy_list, self.std = self.classfier_cv(classfier=classfier)

    # to be continued......
    def classfier_cv(self, classfier='knn', k_for_cv=10):
        global estimator
        if classfier == 'knn':
            estimator = KNeighborsClassifier(n_neighbors=3)
        elif classfier == 'svm':
            estimator = SVC(kernel='poly')
        total_sum = 0
        temp_accuracy_list = []
        for i in range(0, k_for_cv):
            train_index, test_index = self.mil.get_index(para_k=k_for_cv)
            temp_sum = 0
            for index in range(k_for_cv):  # 一轮CV
                x_train = self.trsed_vector_matrix[train_index[index], :-1]
                y_train = self.trsed_vector_matrix[train_index[index], -1]

                x_test = self.trsed_vector_matrix[test_index[index], :-1]
                y_test = self.trsed_vector_matrix[test_index[index], -1]

                estimator.fit(x_train, y_train)
                score = estimator.score(x_test, y_test)
                temp_sum += score
            temp_accuracy = temp_sum / k_for_cv
            total_sum += temp_accuracy
            temp_accuracy_list.append(temp_accuracy)
            # print("第 %s 次 %s CV 的平均准确度为 %s" % (i, k_for_CV, temp_accuracy))
        accuracy = total_sum / k_for_cv
        # print("%s 倍交叉验证的平均准确度为 %s" % (k_for_CV, accuracy))
        # print('accuracy_list', temp_accuracy_list)
        # print('classfier:', classfier)
        return accuracy, temp_accuracy_list, np.std(temp_accuracy_list, ddof=1)

    def get_trsed_vector_matrix(self):
        # print('computing transformed vector matrix........')
        temp_trsed_vector_matrix = np.zeros((self.mil.num_bags, len(self.key_bags_list) + 1))
        for i in range(0, self.mil.num_bags):
            for j in range(0, len(self.key_bags_list)):
                temp_trsed_vector_matrix[i, j] = self.bags_dis_matrix[i, self.key_bags_list[j]]
            temp_trsed_vector_matrix[i, -1] = self.mil.bags_label[i]
        return temp_trsed_vector_matrix

    def get_key_bags_list(self, u_for_total_DP, kernel):
        # print('computing key bags list........')
        dp = DP()
        dp.train(self.bags_dis_matrix, u=u_for_total_DP, kernel=kernel)
        return dp.center_list

    def get_bags_dis_matrix(self, dis_file):
        temp_matrix = np.loadtxt(dis_file)
        return temp_matrix


if __name__ == '__main__':
    start = time.process_time()

    # smmd = SMMD(kernel='gaussian',
    #             file_path=r'..\MILframe\data\Newsgroups\unnormalized\alt_atheism.mat',
    #             dis_file_path=r'..\distance\SMMD\Newsgroups\alt_atheism.mat\ave\0.9_ave_alt_atheism.mat',
    #             u_for_total_DP=1)
    # print('准确率', smmd.accuracy)
    # print(smmd.accuracy_list)
    # print('标准差', smmd.std)
    u_list = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1]
    dis_measure_list = ['ave_h', 'max_h', 'min_h', 'vir_h']
    # dis_measure_list = ['vir_h']
    # 数据集路径
    file_path = r'..\MILframe\data\benchmark'  # 下面就是直接的数据集文件
    # 结果存放路径
    output_path = r'result\benchmark_result'  # 下面为数据集命名的文件夹，然后是距离命名的文件夹
    # 使用的距离路径
    dis_path = r'..\distance\SMMD\Benchmark'  # 下面是数据集命名的文件夹
    dataset_name_list = os.listdir(dis_path)
    # dataset_name_list.remove('readme.txt')  # 除去了readme.txt文件的所有文件夹
    for dataset_name in dataset_name_list:  # 遍历数据集文件
        in_path1 = os.path.join(dis_path, dataset_name)
        print(in_path1)  # in_path1路径到数据集名称文件夹
        out_path1 = os.path.join(output_path, dataset_name)  # + '1'
        os.makedirs(out_path1)  # 创建数据集命名的文件夹
        for dis_measure in dis_measure_list:  # 遍历距离度量
            in_path2 = os.path.join(in_path1, dis_measure.split('_')[0])  # in_path2路径到数据集名称文件夹下的距离度量文件夹
            print(' ', in_path2)
            out_path2 = os.path.join(out_path1, dis_measure.split('_')[0])
            os.makedirs(out_path2)  # 在对应数据集名文件夹下创建不同距离度量文件夹
            for dis_file in os.listdir(in_path2):  # 遍历所有包内聚类距离产生的包间距离矩阵
                in_path3 = os.path.join(in_path2, dis_file)  # in_path3到具体的各个包内聚类数时的包间距离文件
                print(in_path3)
                result_file_name = 'result_' + dataset_name.split('.')[0] + '_' + dis_measure + '.txt'
                out_path3 = os.path.join(out_path2, result_file_name)
                output = open(out_path3, 'a', encoding='utf8')  # a表示追加模式
                for u in u_list:
                    smmd = SMMD(dis_file_path=in_path3,
                                file_path=os.path.join(file_path, dataset_name),
                                u_for_total_DP=u)
                    string = dataset_name + '\t' + dis_file[:3] + '\t' + str(u) + ' ' + dis_measure + ' ' + str(smmd.accuracy) + ' ' + str(smmd.std)
                    # string = string + ' ' + dis_file
                    output.write(str(string))  # write函数不能写int类型的参数，所以使用str()转化
                    output.write('\n')  # 写完一行立马换行
                output.close()

    end = time.process_time()
    print('本次运行耗时 %s 秒' % (end - start))
