import os
import re
import numpy as np
"""从不同包内聚类和包间聚类的比例的结果文件中找出最佳的参数,数据集名    距离度量    包内聚类比例   包外聚类比例 准确率  标准差"""
result_file = r'result\Newsgroups_result'
best_result_path = r'result\Newsgroups_result\best_result_on_benchmark.txt'

best_best_matrix = []
for result_name in os.listdir(result_file):
    path1 = os.path.join(result_file, result_name)  # path1为数据集名的文件夹
    print(path1)
    best_matrix = []
    for dis_measure in os.listdir(path1):
        path2 = os.path.join(path1, dis_measure)  # path2为数据集名文件夹下的距离度量文件夹
        print('--', path2)
        for result_file_name in os.listdir(path2):
            path3 = os.path.join(path2, result_file_name)  # path3为具体的result txt文件
            print('----', path3)
            f = open(path3, 'r')
            lines = f.readlines()
            data = [None] * len(lines)
            i = 0
            for line in lines:
                string = re.split(r'[ \t\n]\s*', line)[:-1]  # 使用正则表达式用空格和tab和换行符分隔字符串
                # print(string)
                data[i] = [string[0], string[1], string[2], string[3], string[4]]
                i = i + 1
            f.close()
            # 找出data中最高的准确率和对应的参数及std
            data = np.array(data)
            ratio_list = data[:, 1]
            u_list = data[:, 2]
            acc_list = data[:, 3]
            std_list = data[:, -1]
            best_acc_index = np.argmax(acc_list)  # 找到最大值下标
            best_ratio = ratio_list[best_acc_index]
            best_u = u_list[best_acc_index]
            best_acc = acc_list[best_acc_index]
            best_std = std_list[best_acc_index]
            best_vector = [dis_measure, best_ratio, best_u, best_acc, best_std]
            best_matrix.append(best_vector)  # 对应数据集在四种距离下分别的最好参数
    best_matrix = np.array(best_matrix)
    print(best_matrix)
    final_dis_list = best_matrix[:, 0]
    final_ratio_list = best_matrix[:, 1]
    final_u_list = best_matrix[:, 2]
    final_acc_list = best_matrix[:, 3]
    final_std_list = best_matrix[:, -1]

    final_best_acc_index = np.argmax(final_acc_list)

    final_best_dis = final_dis_list[final_best_acc_index]
    final_best_ratio = final_ratio_list[final_best_acc_index]
    final_best_u = final_u_list[final_best_acc_index]
    final_best_acc = final_acc_list[final_best_acc_index]
    final_best_std = final_std_list[final_best_acc_index]
    final_best_vector = [result_name, final_best_dis + '_h', final_best_ratio, final_best_u, final_best_acc, final_best_std]
    best_best_matrix.append(final_best_vector)
print(best_best_matrix)  # best_best_matrix为每个数据集准确率最高的距离，参数，准确率和std
best_best_matrix = np.array(best_best_matrix)
output = open(best_result_path, 'w', encoding='gbk')
# 矩阵写入文件
for i in range(len(best_best_matrix)):
    for j in range(len(best_best_matrix[i])):
        output.write(str(best_best_matrix[i][j]))  #write函数不能写int类型的参数，所以使用str()转化
        output.write('\t')  #相当于Tab一下，换一个单元格
    output.write('\n')    #写完一行立马换行
output.close()

