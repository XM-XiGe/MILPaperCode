from MILframe import MIL
import numpy as np
import os
import time

class DisToTxt:
    """计算每个数据集之间的四种豪斯多夫距离，存为txt文件"""
    def __init__(self,
                 dis_measure='ave_h',
                 file_path='MILframe/data/Text/rec_motorcycles+.mat',
                 dis_save_path="distance/Text/rec_motorcycles+_ave_hausdorff_euclidean.txt', 'w', encoding='gbk"):
        self.mil = MIL.MIL(file_path)
        self.dis_matrix = self.compute_dis_matrix(dis_measure)
        self.dis_to_txt(dis_save_path)

    # 第i个包和第j个包之间的平均豪斯多夫距离
    def ave_hausdorff(self, i, j):
        sum = 0
        if i == j:
            return sum
        for i_ins in self.mil.bags[i, 0][:, :-1]:
            dis_to_i = []
            for j_ins in self.mil.bags[j, 0][:, :-1]:
                dis_to_i.append(self.dis_between_ins(i_ins, j_ins))
            sum = sum + min(dis_to_i)
        for j_ins in self.mil.bags[j, 0][:, :-1]:
            dis_to_j = []
            for i_ins in self.mil.bags[i, 0][:, :-1]:
                dis_to_j.append(self.dis_between_ins(j_ins, i_ins))
            sum = sum + min(dis_to_j)
        # print(self.mil.bags[i, 0].shape[0], self.mil.bags[j, 0].shape[0])
        return sum / (self.mil.bags[i, 0].shape[0] + self.mil.bags[j, 0].shape[0])


    # 测量两个bag之间的距离(最小豪斯多夫)
    def min_hausdorff(self, i, j):
        if i == j:
            return 0
        dis_ij = []
        for instance_i in self.mil.bags[i, 0][:, :-1]:
            for instance_j in self.mil.bags[j, 0][:, :-1]:
                dis_ij.append(self.dis_between_ins(instance_j, instance_i))
        min_ij = min(dis_ij)
        # print(dis_ij,min_ij)
        return min_ij

    def max_hausdorff(self, i, j):
        if i == j:
            return 0
        total_list = []
        for i_ins in self.mil.bags[i, 0][:, :-1]:
            dis_to_i = []
            for j_ins in self.mil.bags[j, 0][:, :-1]:
                dis_to_i.append(self.dis_between_ins(i_ins, j_ins))
            total_list.append(min(dis_to_i))
        for j_ins in self.mil.bags[j, 0][:, :-1]:
            dis_to_j = []
            for i_ins in self.mil.bags[i, 0][:, :-1]:
                dis_to_j.append(self.dis_between_ins(j_ins, i_ins))
            total_list.append(min(dis_to_j))
        return max(total_list)

    def dis_between_ins(self, ins1, ins2):
        return np.sqrt(np.sum(np.power((ins1 - ins2), 2)))

    def compute_dis_matrix(self, dis_measure):
        temp_matrix = np.zeros((self.mil.num_bags, self.mil.num_bags))
        if dis_measure == 'ave_h':
            for i in range(self.mil.num_bags):
                for j in range(self.mil.num_bags):
                    temp_matrix[i, j] = self.ave_hausdorff(i, j)
        if dis_measure == 'min_h':
            for i in range(self.mil.num_bags):
                for j in range(self.mil.num_bags):
                    temp_matrix[i, j] = self.min_hausdorff(i, j)
        if dis_measure == 'max_h':
            for i in range(self.mil.num_bags):
                for j in range(self.mil.num_bags):
                    temp_matrix[i, j] = self.max_hausdorff(i, j)
        if dis_measure == 'vir_h':
            for i in range(self.mil.num_bags):
                for j in range(self.mil.num_bags):
                    temp_matrix[i, j] = self.vir_hausdorff(i, j)
        return temp_matrix

    def vir_hausdorff(self, i, j):
        matrix_i = np.array(self.mil.bags[i, 0][:, :-1])
        matrix_j = np.array(self.mil.bags[j, 0][:, :-1])
        center_i = matrix_i.sum(axis=0) / self.mil.bags_size[i]  # 每一列元素相加之和再除示例数
        center_j = matrix_j.sum(axis=0) / self.mil.bags_size[j]
        return self.dis_between_ins(center_i, center_j)

    def dis_to_txt(self, dis_save_path):
        output = open(dis_save_path, 'w', encoding='gbk')
        for i in range(len(self.dis_matrix)):
            for j in range(len(self.dis_matrix[i])):
                output.write(str(self.dis_matrix[i][j]))  #write函数不能写int类型的参数，所以使用str()转化
                output.write('\t')  #相当于Tab一下，换一个单元格
            output.write('\n')    #写完一行立马换行
        output.close()

if __name__ == '__main__':
    start = time.process_time()

    file_path = r'MILframe\data\Newsgroups\unnormalized'
    out_path = r'distance\Newsgroups\unnormalized'
    dis_measure_list = ['ave_h', 'max_h', 'min_h', 'vir_h']

    for filename in os.listdir(file_path):
        in_path1 = os.path.join(file_path, filename)  # in_path1为具体的数据集文件
        print(in_path1)
        out_path1 = os.path.join(out_path, filename)
        os.makedirs(out_path1)  # 创建数据集命名的文件夹
        for dis_measure in dis_measure_list:
            print('--', dis_measure)
            out_path2 = os.path.join(out_path1, dis_measure.split('_')[0])
            os.makedirs(out_path2)  # 创建数据集文件夹下的不同距离的文件夹
            dis_file_name = filename.split('.')[0] + '_' + dis_measure + '_' + '.txt'
            out_path3 = os.path.join(out_path2, dis_file_name)
            # 计算距离矩阵，存为txt，放进对应文件夹
            distotxt = DisToTxt(file_path=in_path1,
                                dis_measure=dis_measure,
                                dis_save_path=out_path3)
    end = time.process_time()
    print('cost time:', end - start)