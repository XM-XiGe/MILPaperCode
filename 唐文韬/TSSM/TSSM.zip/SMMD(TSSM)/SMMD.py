from MILframe import MIL
from DP_TWT import DP
import numpy as np
import time
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC


class SMMD:
    """
    每个包中先使用局部DP，聚类出一半的实例，代表包的信息
    """
    def __init__(self, kernel='gaussian', ratio_for_inbag_dp=0.1, classfier='knn', file_path='..\\MILframe\\data\\benchmark\\musk1.mat', dis_measure='ave_h',u_for_total_DP=0.4):
        self.mil = MIL.MIL(file_path)
        self.key_ins_inbags_dict = self.get_key_ins_inbags_dict(ratio_for_inbag_dp, kernel)
        #print(self.key_ins_inbags_dict)  # 不包含标签
        self.bags_dis_matrix = self.get_bags_dis_matrix(dis_measure)
        print(self.bags_dis_matrix)
        self.key_bags_list = self.get_key_bags_list(u_for_total_DP, kernel)
        self.key_bags_list.sort()
        #print(self.key_bags_list)
        self.trsed_vector_matrix = self.get_trsed_vector_matrix()  # 最后一列为标签
        #print(self.trsed_vector_matrix)
        self.accuracy, self.accuracy_list, self.std = self.classfier_cv(classfier=classfier)

    # to be continued......
    def classfier_cv(self, classfier='knn', k_for_cv=10):
        global estimator
        if classfier == 'knn':
            estimator = KNeighborsClassifier(n_neighbors=3)
        elif classfier == 'svm':
            estimator = SVC(kernel='poly')
        total_sum = 0
        temp_accuracy_list = []
        for i in range(0, k_for_cv):
            train_index, test_index = self.mil.get_index(para_k=k_for_cv)
            temp_sum = 0
            for index in range(k_for_cv):  # 一轮CV
                x_train = self.trsed_vector_matrix[train_index[index], :-1]
                y_train = self.trsed_vector_matrix[train_index[index], -1]

                x_test = self.trsed_vector_matrix[test_index[index], :-1]
                y_test = self.trsed_vector_matrix[test_index[index], -1]

                estimator.fit(x_train, y_train)
                score = estimator.score(x_test, y_test)
                temp_sum += score
            temp_accuracy = temp_sum / k_for_cv
            total_sum += temp_accuracy
            temp_accuracy_list.append(temp_accuracy)
            # print("第 %s 次 %s CV 的平均准确度为 %s" % (i, k_for_CV, temp_accuracy))
        accuracy = total_sum / k_for_cv
        # print("%s 倍交叉验证的平均准确度为 %s" % (k_for_CV, accuracy))
        # print('accuracy_list', temp_accuracy_list)
        # print('classfier:', classfier)
        return accuracy, temp_accuracy_list, np.std(temp_accuracy_list, ddof=1)

    def get_trsed_vector_matrix(self):
        #print('computing transformed vector matrix........')
        temp_trsed_vector_matrix = np.zeros((self.mil.num_bags, len(self.key_bags_list) + 1))
        for i in range(0, self.mil.num_bags):
            for j in range(0, len(self.key_bags_list)):
                temp_trsed_vector_matrix[i, j] = self.bags_dis_matrix[i, self.key_bags_list[j]]
            temp_trsed_vector_matrix[i, -1] = self.mil.bags_label[i]
        return temp_trsed_vector_matrix

    def get_key_bags_list(self, u_for_total_DP, kernel):
        #print('computing key bags list........')
        dp = DP()
        dp.train(self.bags_dis_matrix, u=u_for_total_DP,kernel=kernel)
        return dp.center_list

    def get_bags_dis_matrix(self, dis_measure):
        #print('computing bags dis matrix........')
        if dis_measure == 'ave_h':
            temp_bags_dis_matrix = np.zeros((self.mil.num_bags, self.mil.num_bags))
            for i in range(0, self.mil.num_bags):
                for j in range(0, self.mil.num_bags):
                    temp_bags_dis_matrix[i, j] = self.ave_hausdorff(i, j)
            return temp_bags_dis_matrix
        elif dis_measure == 'max_h':
            temp_bags_dis_matrix = np.zeros((self.mil.num_bags, self.mil.num_bags))
            for i in range(0, self.mil.num_bags):
                for j in range(0, self.mil.num_bags):
                    temp_bags_dis_matrix[i, j] = self.max_hausdorff(i, j)
            return temp_bags_dis_matrix
        elif dis_measure == 'min_h':
            temp_bags_dis_matrix = np.zeros((self.mil.num_bags, self.mil.num_bags))
            for i in range(0, self.mil.num_bags):
                for j in range(0, self.mil.num_bags):
                    temp_bags_dis_matrix[i, j] = self.min_hausdorff(i, j)
            return temp_bags_dis_matrix
        elif dis_measure == 'vir_h':
            temp_bags_dis_matrix = np.zeros((self.mil.num_bags, self.mil.num_bags))
            for i in range(0, self.mil.num_bags):
                for j in range(0, self.mil.num_bags):
                    temp_bags_dis_matrix[i, j] = self.vir_hausdorff(i, j)
            return temp_bags_dis_matrix

    # 第i个包和第j个包之间的平均豪斯多夫距离
    def ave_hausdorff(self, i, j):
        sum = 0
        if i == j:
            return sum
        for i_ins in self.key_ins_inbags_dict[i]:
            dis_to_i = []
            for j_ins in self.key_ins_inbags_dict[j]:
                dis_to_i.append(self.dis_between_ins(i_ins, j_ins))
            sum = sum + min(dis_to_i)
        for j_ins in self.key_ins_inbags_dict[j]:
            dis_to_j = []
            for i_ins in self.key_ins_inbags_dict[i]:
                dis_to_j.append(self.dis_between_ins(j_ins, i_ins))
            sum = sum + min(dis_to_j)
        # print(self.mil.bags[i, 0].shape[0], self.mil.bags[j, 0].shape[0])
        return sum / (self.mil.bags[i, 0].shape[0] + self.mil.bags[j, 0].shape[0])

    # 测量两个bag之间的距离(最小豪斯多夫)
    def min_hausdorff(self, i, j):
        if i == j:
            return 0
        dis_ij = []
        for instance_i in self.key_ins_inbags_dict[i]:
            for instance_j in self.key_ins_inbags_dict[j]:
                dis_ij.append(self.dis_between_ins(instance_j, instance_i))
        min_ij = min(dis_ij)
        # print(dis_ij,min_ij)
        return min_ij

    def max_hausdorff(self, i, j):
        if i == j:
            return 0
        total_list = []
        for i_ins in self.key_ins_inbags_dict[i]:
            dis_to_i = []
            for j_ins in self.key_ins_inbags_dict[j]:
                dis_to_i.append(self.dis_between_ins(i_ins, j_ins))
            total_list.append(min(dis_to_i))
        for j_ins in self.key_ins_inbags_dict[j]:
            dis_to_j = []
            for i_ins in self.key_ins_inbags_dict[i]:
                dis_to_j.append(self.dis_between_ins(j_ins, i_ins))
            total_list.append(min(dis_to_j))
        return max(total_list)

    def vir_hausdorff(self, i, j):
        matrix_i = np.array(self.key_ins_inbags_dict[i])
        matrix_j = np.array(self.key_ins_inbags_dict[j])
        center_i = matrix_i.sum(axis=0) / self.mil.bags_size[i]  # 每一列元素相加之和再除示例数
        center_j = matrix_j.sum(axis=0) / self.mil.bags_size[j]
        return self.dis_between_ins(center_i, center_j)

    def get_key_ins_inbags_dict(self, ratio_for_inbag_dp, kernel):
        #print('computing key ins in bags dict........')
        temp_dict = {}
        for i in range(0, self.mil.num_bags):
            temp_dict[i] = self.get_key_ins_inbags_1(i, ratio_for_inbag_dp, kernel)
        return temp_dict

    # version 1
    def get_key_ins_inbags_1(self, i, ratio_for_inbag_dp, kernel):
        if ratio_for_inbag_dp == 1:
            return self.mil.bags[i, 0][:, :-1]
        elif self.mil.bags_size[i] * ratio_for_inbag_dp > 1:
            instances = self.mil.bags[i, 0][:, :-1]
            dis_matrix = self.get_dis_matrix_inbags(i)
            dp = DP()
            dp.train(dis_matrix, u=ratio_for_inbag_dp, kernel=kernel)
            key_idx = dp.center_list
            key_ins = instances[key_idx]
            return key_ins
        else:
            instances = self.mil.bags[i, 0][:, :-1]
            return instances

    def get_dis_matrix_inbags(self, i):
        instances = self.mil.bags[i, 0][:, :-1] #最后一列为标签，要去掉。
        temp_dis_matrix = np.zeros((self.mil.bags_size[i], self.mil.bags_size[i]))
        for m in range(0, self.mil.bags_size[i]):
            for n in range(0, self.mil.bags_size[i]):
                temp_dis_matrix[m][n] = self.dis_between_ins(instances[m], instances[n])
        return temp_dis_matrix

    def dis_between_ins(self, ins1, ins2):
        #return np.sqrt((np.sum((ins1 - ins2) ** 2)))
        return np.sqrt(np.sum(np.power((ins1 - ins2), 2)))


if __name__ == '__main__':
    start = time.process_time()
    """
    for musk1: ratio_for_inbag_dp = 0.1,u_for_total_DP = [0.6, 0.7, 0.8, 0.9]时效果较好，其中0.7, 0.8 效果最好
    for musk2:ratio_for_inbag_dp=[0.5, 0.6, 0.8]时效果较好
    for elephant:ratio_for_inbag_dp=[0.7, 0.8, 0.9]时效果较好
    
    """
    file_path_list = ['..\\MILframe\\data\\benchmark\\musk1+.mat',
                      '..\\MILframe\\data\\benchmark\\musk2+.mat',
                      '..\\MILframe\\data\\benchmark\\elephant+.mat',
                      '..\\MILframe\\data\\benchmark\\tiger+.mat',
                      '..\\MILframe\\data\\benchmark\\fox+.mat']
    dis_list = ['ave_h', 'max_h', 'min_h', 'vir_h']
    smmd = SMMD(ratio_for_inbag_dp=0.1,
                u_for_total_DP=0.7,
                classfier='knn',
                file_path='../MILframe/data/benchmark/musk1.mat',
                dis_measure=dis_list[0],
                kernel='gaussian')
    print(smmd.accuracy, smmd.accuracy_list)
    print('标准差为', smmd.std)
    # print(lds.key_ins_inbags_dict[0])

    end = time.process_time()
    print('本次运行耗时 %s 秒' % (end - start))
