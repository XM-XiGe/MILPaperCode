from SMMD_use_saved_dis import SMMD
import numpy as np
import os
import time
"""计算某种距离下某个数据集所有参数的acc，包内聚类参数为0.1-0.9，包间聚类参数为0.1-1，acc为重复多次的最高，写入out_path的文件"""
start = time.process_time()
acc_matrix = np.zeros((9, 10))
ratio_list = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]
u_list = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1]
dataset_name = 'tiger.mat'
dis_measure = 'min'
dataset_file_path = r'../MILframe/data/benchmark/' + dataset_name
dis_path = r'../distance/SMMD/Benchmark/' + dataset_name + '/' + dis_measure
out_path = r'result/benchmark_result/heat_map_result.txt'
i = 0
for dis_file_name in os.listdir(dis_path):
    dis_file_path = os.path.join(dis_path, dis_file_name)
    print(dis_file_name)
    for j in range(len(u_list)):
        acc_list = []
        for k in range(10):
            smmd = SMMD(dis_file_path=dis_file_path,
                        file_path=dataset_file_path,
                        u_for_total_DP=u_list[j])
            acc_list.append(smmd.accuracy)
            acc_matrix[i, j] = np.round(np.max(acc_list) * 100, decimals=1)
    i += 1

num_row = len(acc_matrix)
num_col = len(acc_matrix[0])
output = open(out_path, 'a', encoding='gbk')  # a为追加模式
output.write('  ' + dis_measure + ' ' + dataset_file_path.split('/')[-1].split('.')[0] + '\n')
output.write('  [[')
for i in range(num_row):
    if i == 0:
        pass
    else:
        output.write('   [')  # 矩阵每一行前空三格加一个左方括号，保证格式
    for j in range(num_col):
        if j != num_col - 1:  # 不是每行的最后一个，后接逗号
            output.write(str(acc_matrix[i, j]) + ', ')  # write函数不能写int类型的参数，所以使用str()转化
        else:  # 为每行的最后一个
            if i != num_row - 1:  # 若不是最后一行的最后一个
                output.write(str(acc_matrix[i, j]) + '],')
            else:  # 若是最后一行的最后一个
                output.write(str(acc_matrix[i, j]) + ']]')
    output.write('\n')  # 写完一行立马换行
output.close()
print(acc_matrix)

end = time.process_time()
print('time cost:', end - start)
