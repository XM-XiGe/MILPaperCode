from MILframe import MIL
from DP_TWT import DP
import numpy as np
import time
import os


class SMMD:
    """
    每个包中先使用不同参数的局部DP，然后计算包之间的距离矩阵，存下来备用
    """
    def __init__(self, dis_output_path, kernel='gaussian',
                 ratio_for_inbag_dp=0.1,
                 dis_measure='ave_h',
                 dataset_path='..\\MILframe\\data\\benchmark\\musk1.mat'):
        self.mil = MIL.MIL(dataset_path)
        self.key_ins_inbags_dict = self.get_key_ins_inbags_dict(ratio_for_inbag_dp, kernel)
        self.bags_dis_matrix = self.get_bags_dis_matrix(dis_measure=dis_measure, dis_file=dis_output_path)

    def get_bags_dis_matrix(self, dis_measure, dis_file):
        if dis_measure == 'ave_h':
            temp_bags_dis_matrix = np.zeros((self.mil.num_bags, self.mil.num_bags))
            for i in range(0, self.mil.num_bags):
                for j in range(0, self.mil.num_bags):
                    temp_bags_dis_matrix[i, j] = self.ave_hausdorff(i, j)
        elif dis_measure == 'max_h':
            temp_bags_dis_matrix = np.zeros((self.mil.num_bags, self.mil.num_bags))
            for i in range(0, self.mil.num_bags):
                for j in range(0, self.mil.num_bags):
                    temp_bags_dis_matrix[i, j] = self.max_hausdorff(i, j)
        elif dis_measure == 'min_h':
            temp_bags_dis_matrix = np.zeros((self.mil.num_bags, self.mil.num_bags))
            for i in range(0, self.mil.num_bags):
                for j in range(0, self.mil.num_bags):
                    temp_bags_dis_matrix[i, j] = self.min_hausdorff(i, j)
        elif dis_measure == 'vir_h':
            temp_bags_dis_matrix = np.zeros((self.mil.num_bags, self.mil.num_bags))
            for i in range(0, self.mil.num_bags):
                for j in range(0, self.mil.num_bags):
                    temp_bags_dis_matrix[i, j] = self.vir_hausdorff(i, j)
        # 将距离矩阵写入文件
        output = open(dis_file, 'w', encoding='gbk')
        for i in range(len(temp_bags_dis_matrix)):
            for j in range(len(temp_bags_dis_matrix[i])):
                output.write(str(temp_bags_dis_matrix[i][j]))  # write函数不能写int类型的参数，所以使用str()转化
                output.write('\t')  # 相当于Tab一下，换一个单元格
            output.write('\n')  # 写完一行立马换行
        output.close()

    # 第i个包和第j个包之间的平均豪斯多夫距离
    def ave_hausdorff(self, i, j):
        sum = 0
        if i == j:
            return sum
        for i_ins in self.key_ins_inbags_dict[i]:
            dis_to_i = []
            for j_ins in self.key_ins_inbags_dict[j]:
                dis_to_i.append(self.dis_between_ins(i_ins, j_ins))
            sum = sum + min(dis_to_i)
        for j_ins in self.key_ins_inbags_dict[j]:
            dis_to_j = []
            for i_ins in self.key_ins_inbags_dict[i]:
                dis_to_j.append(self.dis_between_ins(j_ins, i_ins))
            sum = sum + min(dis_to_j)
        # print(self.mil.bags[i, 0].shape[0], self.mil.bags[j, 0].shape[0])
        return sum / (self.mil.bags[i, 0].shape[0] + self.mil.bags[j, 0].shape[0])

    # 测量两个bag之间的距离(最小豪斯多夫)
    def min_hausdorff(self, i, j):
        if i == j:
            return 0
        dis_ij = []
        for instance_i in self.key_ins_inbags_dict[i]:
            for instance_j in self.key_ins_inbags_dict[j]:
                dis_ij.append(self.dis_between_ins(instance_j, instance_i))
        min_ij = min(dis_ij)
        # print(dis_ij,min_ij)
        return min_ij

    def max_hausdorff(self, i, j):
        if i == j:
            return 0
        total_list = []
        for i_ins in self.key_ins_inbags_dict[i]:
            dis_to_i = []
            for j_ins in self.key_ins_inbags_dict[j]:
                dis_to_i.append(self.dis_between_ins(i_ins, j_ins))
            total_list.append(min(dis_to_i))
        for j_ins in self.key_ins_inbags_dict[j]:
            dis_to_j = []
            for i_ins in self.key_ins_inbags_dict[i]:
                dis_to_j.append(self.dis_between_ins(j_ins, i_ins))
            total_list.append(min(dis_to_j))
        return max(total_list)

    def vir_hausdorff(self, i, j):
        matrix_i = np.array(self.key_ins_inbags_dict[i])
        matrix_j = np.array(self.key_ins_inbags_dict[j])
        center_i = matrix_i.sum(axis=0) / self.mil.bags_size[i]  # 每一列元素相加之和再除示例数
        center_j = matrix_j.sum(axis=0) / self.mil.bags_size[j]
        return self.dis_between_ins(center_i, center_j)

    def get_key_ins_inbags_dict(self, ratio_for_inbag_dp, kernel):
        #print('computing key ins in bags dict........')
        temp_dict = {}
        for i in range(0, self.mil.num_bags):
            temp_dict[i] = self.get_key_ins_inbags_1(i, ratio_for_inbag_dp, kernel)
        return temp_dict

    # version 1
    def get_key_ins_inbags_1(self, i, ratio_for_inbag_dp, kernel):
        if ratio_for_inbag_dp == 1:
            return self.mil.bags[i, 0][:, :-1]
        elif self.mil.bags_size[i] * ratio_for_inbag_dp > 1:
            instances = self.mil.bags[i, 0][:, :-1]
            dis_matrix = self.get_dis_matrix_inbags(i)
            dp = DP()
            dp.train(dis_matrix, u=ratio_for_inbag_dp, kernel=kernel)
            key_idx = dp.center_list
            key_ins = instances[key_idx]
            return key_ins
        else:
            instances = self.mil.bags[i, 0][:, :-1]
            return instances

    def get_dis_matrix_inbags(self, i):
        instances = self.mil.bags[i, 0][:, :-1] #最后一列为标签，要去掉。
        temp_dis_matrix = np.zeros((self.mil.bags_size[i], self.mil.bags_size[i]))
        for m in range(0, self.mil.bags_size[i]):
            for n in range(0, self.mil.bags_size[i]):
                temp_dis_matrix[m][n] = self.dis_between_ins(instances[m], instances[n])
        return temp_dis_matrix

    def dis_between_ins(self, ins1, ins2):
        #return np.sqrt((np.sum((ins1 - ins2) ** 2)))
        return np.sqrt(np.sum(np.power((ins1 - ins2), 2)))


if __name__ == '__main__':
    start = time.process_time()
    # os.mkdir(os.path.join(out_path, 'ave_h')) 创建目录
    # os.path.join() 拼接路径
    dis_measure_list = ['ave_h', 'max_h', 'min_h', 'vir_h']
    # dis_measure_list = ['vir_h']
    ratio_list = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]
    # ratio_list = [0.6, 0.7, 0.8, 0.9]
    out_path = r'..\distance\SMMD\Benchmark'  # 此目录下为数据集文件名，然后试四个距离文件夹
    dataset_path = r'..\MILframe\data\benchmark'  # 此目录下为数据集的.mat文件
    for filename in os.listdir(dataset_path):
        print('computing dis for ' + filename)
        file_path = os.path.join(dataset_path, filename)  # 获取文件夹下的所有文件名(数据集)
        path1 = os.path.join(out_path, filename)  # 以文件名为第一目录
        os.makedirs(path1)
        for dis_measure in dis_measure_list:
            path2 = os.path.join(path1, dis_measure.split('_')[0])
            os.makedirs(path2)  # 以距离度量为第二目录
            print('    compute', dis_measure)
            for ratio in ratio_list:
                print('        ratio:', ratio)
                smmd = SMMD(ratio_for_inbag_dp=ratio,
                            dataset_path=file_path,
                            dis_measure=dis_measure,
                            dis_output_path=os.path.join(path2, str(ratio) + '_' + dis_measure.split('_')[0] + '_' + filename.split('.')[0] + '.txt'))

    # smmd = SMMD(ratio_for_inbag_dp=0.5,
    #             dataset_path='',
    #             dis_measure='ave_h',
    #             kernel='gaussian',
    #             dis_output_path='')


    end = time.process_time()
    print('本次运行耗时 %s 秒' % (end - start))
