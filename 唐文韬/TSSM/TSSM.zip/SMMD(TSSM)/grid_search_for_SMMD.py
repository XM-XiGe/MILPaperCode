import SMMD
import numpy as np
ratio_for_inbag_dp_list = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]
u_for_total_DP_list = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1]
for ratio in ratio_for_inbag_dp_list:
    # 配置输出文件的路径。
    path = 'result/benchmark_result/max/result_musk2_max_h.txt'
    # 打开文件
    f = open(path, "a")
    for u in u_for_total_DP_list:
        file_path = '..\\MILframe\\data\\benchmark\\musk2.mat'
        lds = SMMD.SMMD(ratio_for_inbag_dp=ratio,
                        u_for_total_DP=u,
                        file_path=file_path,
                        dis_measure='max_h')
        accuracy = lds.accuracy
        accuracy_list = lds.accuracy_list
        file_name = file_path.split('\\')[-1]
        std = lds.std
        #print(file_name)
        result = '当数据集为 % s ，ratio 为 %s , u 为 % s时，准确率为 %s, 标准差为 %s\n' % (file_name, ratio, u, accuracy, std)
        print(result)
        # 文件内写入“文本内容”四个字
        f.write(result)
        # 关闭文件
    f.close()
